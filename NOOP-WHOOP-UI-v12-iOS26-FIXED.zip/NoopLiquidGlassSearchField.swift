import SwiftUI

// MARK: - Compatible search field
//
// Xcode 16.4 / iOS 18-compatible implementation.
// Native iOS 26 Liquid Glass APIs are intentionally not referenced here because
// they are unavailable to the Xcode 16.4 SDK. The search field keeps the same
// layout, accessibility, focus handling, and clear control while using the
// shared elevated search surface.

/// Full-width rounded search field.
public struct NoopLiquidGlassSearchField: View {
    @Binding private var text: String
    private let prompt: String
    private let accessibilityPrompt: String
    private var externalFocus: FocusState<Bool>.Binding?
    @FocusState private var internalFocus: Bool

    public init(
        text: Binding<String>,
        prompt: String,
        accessibilityLabel: String? = nil,
        isFocused: FocusState<Bool>.Binding? = nil
    ) {
        self._text = text
        self.prompt = prompt
        self.accessibilityPrompt = accessibilityLabel ?? prompt
        self.externalFocus = isFocused
    }

    public var body: some View {
        HStack(spacing: NoopMetrics.space2) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(StrandPalette.textSecondary)
                .accessibilityHidden(true)

            TextField(prompt, text: $text)
                .textFieldStyle(.plain)
                .font(StrandFont.body)
                .foregroundStyle(StrandPalette.textPrimary)
                .focused(focusBinding)
                .submitLabel(.search)
                #if os(iOS)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
                #endif

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(StrandPalette.textTertiary)
                        .frame(width: 28, height: 28)
                        .contentShape(Circle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(Text("Clear search"))
            }
        }
        .padding(.horizontal, NoopMetrics.space4)
        .padding(.vertical, NoopMetrics.space3)
        .nativeLiquidGlassSearchChrome()
        .accessibilityElement(children: .contain)
        .accessibilityLabel(Text(accessibilityPrompt))
    }

    private var focusBinding: FocusState<Bool>.Binding {
        externalFocus ?? $internalFocus
    }
}

public extension View {

    /// Search-field chrome compatible with Xcode 16.4 / iOS 18.
    ///
    /// Uses the shared elevated pill surface instead of the iOS 26-only
    /// glassEffect API.
    @ViewBuilder
    func nativeLiquidGlassSearchChrome() -> some View {
        self.background(
            NoopPanelSurface(
                cornerRadius: NoopVisualStyle.pillRadius,
                elevated: false
            )
        )
    }

    /// Button chrome compatible with Xcode 16.4.
    ///
    /// The iOS 26 `.glass` button style is intentionally avoided because
    /// Xcode 16.4 does not contain that API in its SDK.
    @ViewBuilder
    func nativeLiquidGlassButtonChrome<Fallback: View>(
        controlSize: ControlSize = .small,
        capsule: Bool = false,
        @ViewBuilder fallback: () -> Fallback
    ) -> some View {
        fallback()
    }

    /// Circular finish layer compatible with Xcode 16.4.
    ///
    /// The iOS 26 glassEffect API is intentionally avoided.
    @ViewBuilder
    func nativeLiquidGlassCircleFinish() -> some View {
        self
    }

    @ViewBuilder
    private func noopStandardSearchChrome() -> some View {
        self.background(
            NoopPanelSurface(
                cornerRadius: NoopVisualStyle.pillRadius,
                elevated: false
            )
        )
    }
}