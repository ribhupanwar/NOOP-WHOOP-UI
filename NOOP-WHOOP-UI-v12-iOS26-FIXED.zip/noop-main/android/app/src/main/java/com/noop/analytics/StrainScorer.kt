package com.noop.analytics

import com.noop.data.HrSample
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToLong

/*
 * StrainScorer.kt — cardiovascular load (NOOP "Effort") on a 0–100 logarithmic scale.
 *
 * Faithful Kotlin port of StrandAnalytics/StrainScorer.swift (verified on macOS),
 * itself ported from server/ingest/app/analysis/strain.py. INDEPENDENT implementation
 * of published exercise-physiology methods (WHOOP-*like*, not a reproduction of the
 * proprietary algorithm; not medical advice).
 *
 * SCALE: the internal metric key stays `strain`, but the published axis is now 0–100
 * ("Effort"). This is a pure RESCALE — `maxStrain` went 21.0 → 100.0 while the
 * denominator D = 7201 is UNCHANGED, so the log curve and its saturation point
 * (TRIMP 7200 ≈ max) are preserved: a max-Effort day stays exactly as rare as a 21.0
 * day was. trimpToStrain now returns 0–100.
 *
 * Pipeline:
 *   1. Heart-Rate Reserve (Karvonen): HRR = HRmax − RHR.
 *   2. Per-sample intensity as %HRR = (HR − RHR) / HRR × 100, clamped 0..100.
 *   3. TRIMP accumulated over the window:
 *        a. Edwards 5-zone summation (default): sample contributes its zone weight
 *           (1..5 at 50/60/70/80/90 %HRR cut-offs) × duration.
 *        b. Banister exponential: sample contributes duration × x × 0.64 × e^(b·x).
 *   4. Logarithmic compression onto [0, 100]:
 *        effort = 100 × ln(TRIMP + 1) / ln(D)
 *      D belongs to the METHOD, not to the scorer: Edwards uses [strainDenominator] (7201, from its
 *      sex-independent 7200 ceiling), Banister its own sex-dependent ceiling + 1. See
 *      [logMapDenominator] — reusing one for the other silently rescales the axis (#1545).
 *
 * References: Karvonen 1957 (%HRR); Edwards 1993 (5-zone TRIMP); Banister 1991
 * (exponential TRIMP, b = 1.92 men / 1.67 women); Tanaka 2001 (HRmax = 208 − 0.7×age).
 *
 * Operates on the Room [HrSample] (ts:Long unix seconds, bpm:Int). The HRR-based
 * zone math here is INDEPENDENT of the %HRmax display zones in [HrZones]; this port
 * uses [HrZones] only where the Swift used HRZones (none in this file — strain has
 * its own Edwards %HRR thresholds).
 */
object StrainScorer {

    // ---- Constants (strain.py) ----

    /** Minimum HR readings before computing strain on a DENSE stream (≈10 min at 1 Hz). */
    const val minReadings: Int = 600
    /**
     * Sparse-stream acceptance (#482/#480): a low-cadence strap — the WHOOP 5/MG sends live
     * standard HR only ~every 30 s — would need ~5 h of continuous wear to reach [minReadings], so
     * Effort sat un-scored (null → a stale prior-day value on the gauge) for most of the day. Also
     * accept once the HR series SPANS at least [minSpanSeconds] of wall-clock with a small sample
     * floor. This never fabricates load: TRIMP still integrates honestly, so a genuine low-HR day
     * scores 0 either way — it just lets the live gauge reflect TODAY. A dense 1 Hz stream is
     * unaffected (it clears [minReadings] first).
     */
    const val minSparseReadings: Int = 20
    /** Wall-clock coverage (seconds) qualifying a sparse stream. 600 s = 10 min, matching the dense
     *  gate's ≈10 min of 600 × 1 Hz samples, so both cadences trust the number at the same age. */
    const val minSpanSeconds: Int = 600

    /** Top of the Effort scale (was 21.0 — rescaled to 0–100 for "Effort"). */
    const val maxStrain: Double = 100.0

    /** Top of WHOOP's Day Strain axis. Every inherited 0–21 value maps through [effortValueFromWhoopStrain]. */
    const val whoopMaxStrain: Double = 21.0

    /**
     * Map any value on WHOOP's 0–21 Day Strain axis onto NOOP's current 0–[maxStrain] Effort axis.
     * This is a value conversion rather than a one-off threshold constant so every range boundary
     * inherited from the 0–21 scale uses the same proportional mapping.
     * Swift twin: `StrainScorer.effortValue`. Multiplies by the pre-divided ratio so the result is
     * bit-identical to the importers' existing rescale of the same fact
     * (WhoopCsvImporter.DAY_STRAIN_TO_EFFORT_SCALE, Swift's dayStrainToEffortScale);
     * `value * maxStrain / whoopMaxStrain` disagrees with them by an ULP on about a quarter of inputs.
     */
    fun effortValueFromWhoopStrain(value: Double): Double = value * (maxStrain / whoopMaxStrain)

    /**
     * Logarithmic-map denominator D. Chosen so the Edwards daily ceiling
     * (top zone weight 5 sustained 24 h = 7200) maps to exactly maxStrain:
     * D = 7200 + 1 = 7201 makes ln(7201)/ln(7201) = 1, so the curve shape and
     * its saturation point are independent of maxStrain (the 21→100 rescale is a
     * pure linear scaling of the whole curve).
     */
    const val strainDenominator: Double = 7201.0

    /**
     * Banister's daily ceiling: 24 h held at ΔHRR = 1.0. Unlike Edwards' 7200 this is SEX-DEPENDENT,
     * because the exponent `b` differs — which is the whole reason [strainDenominator] cannot be reused
     * for it. Feeding Banister TRIMP through the Edwards denominator would score every day against a
     * ceiling ~14% (men) or ~32% (women) higher than Banister can actually reach, so nobody would ever
     * see 100 and the two methods would not be on the same axis. (#1545)
     */
    fun banisterDailyCeiling(b: Double): Double = 24.0 * 60.0 * 1.0 * banisterScale * kotlin.math.exp(b)

    /**
     * The %HRR a waking, sedentary body sits at — the "cost of being alive", not training load.
     *
     * Banister pays at EVERY intensity by design, which is the point: it catches the intermittent work
     * Edwards zeroes. The side effect is that sixteen waking hours of doing nothing accumulate real TRIMP,
     * so a desk day cannot score zero however still you are — while the same day under Edwards, whose
     * first zone starts at 50% HRR, scores exactly zero. A 24 h day held at 5% HRR scores 0 under Edwards
     * and 45 under Banister on the shipped constants. That is not two recipes on one axis; that is two
     * axes (#1624).
     *
     * THIS IS THE ONE TUNED CONSTANT here, and it is a judgement rather than a measurement: low enough not
     * to erase genuine light activity, high enough that ordinary sitting nets to nothing. Resting HR is
     * measured asleep, so a waking body sits above it even at complete rest — which is precisely the gap
     * this closes. Treat it as calibratable, not as physiology.
     */
    const val banisterSedentaryHRR: Double = 0.10

    /** TRIMP per minute at [banisterSedentaryHRR] — the rate subtracted from every day. */
    fun banisterBaselineRatePerMinute(b: Double): Double =
        banisterScale * banisterSedentaryHRR * kotlin.math.exp(b * banisterSedentaryHRR)

    /**
     * The sedentary TRIMP accrued over [minutes] — subtracted from a day's Banister TRIMP so the axis
     * starts where Edwards' does.
     *
     * Subtracted from the DENOMINATOR too (see [logMapDenominator]), so the top of the axis is unmoved: a
     * theoretical maximum day still maps to exactly [maxStrain]. Anchoring only the bottom would trade one
     * mismatched end for the other.
     */
    fun banisterBaseline(minutes: Double, b: Double): Double = banisterBaselineRatePerMinute(b) * minutes


    /**
     * The log-map denominator for a method, so a caller never has to know which constant belongs to
     * which recipe. Ceiling + 1 in both cases, mirroring how [strainDenominator] was derived, so a
     * theoretical maximum day maps to exactly [maxStrain] under either method.
     */
    fun logMapDenominator(method: Method, sex: String): Double = when (method) {
        Method.EDWARDS -> strainDenominator
        Method.BANISTER -> {
            val b = if (sex.lowercase().startsWith("f")) banisterBWomen else banisterBMen
            // Ceiling MINUS a full day of sedentary baseline, matching what is subtracted from the day
            // itself, so both ends of the axis line up with Edwards (#1624).
            banisterDailyCeiling(b) - banisterBaseline(24.0 * 60.0, b) + 1.0
        }
    }
    val lnStrainDenominator: Double get() = ln(strainDenominator)

    /** Fallback per-sample duration (minutes) — 1 s at 1 Hz. */
    const val fallbackSampleMin: Double = 1.0 / 60.0

    const val defaultAge: Int = 30
    const val defaultRestingHR: Double = 60.0

    /** Minimum HR samples before the observed high-percentile HRmax is trusted. */
    const val hrmaxMinSamples: Int = 600

    /** Upper percentile for the observed-HRmax estimate. */
    const val hrmaxPercentile: Double = 99.5

    /** Banister coefficients. */
    const val banisterScale: Double = 0.64
    const val banisterBMen: Double = 1.92
    const val banisterBWomen: Double = 1.67

    /** Edwards zone cut-offs as (%HRR threshold, weight), highest-first. */
    val edwardsZones: List<Pair<Double, Int>> = listOf(
        90.0 to 5, 80.0 to 4, 70.0 to 3, 60.0 to 2, 50.0 to 1,
    )

    /** TRIMP accumulation method. */
    enum class Method { EDWARDS, BANISTER }

    /** Strain calibration / fit errors. Mirrors Swift `StrainError`. */
    enum class StrainError { TOO_FEW_PAIRS, DEGENERATE }

    /** Thrown by [fitStrainDenominator] when the fit is impossible. */
    class StrainException(val error: StrainError) : Exception("Strain fit failed: $error")

    // ---- HRmax helpers ----

    /** Tanaka (2001): HRmax = 208 − 0.7 × age (gender-independent). */
    fun tanakaHRmax(age: Double): Double = 208.0 - 0.7 * age

    /** Classic 220 − age. Last-resort fallback only. */
    fun defaultMaxHR(age: Int = defaultAge): Int = 220 - age

    /** Linear-interpolated percentile of an already-sorted sequence (numpy-style). */
    fun percentile(sortedValues: List<Double>, pct: Double): Double {
        val n = sortedValues.size
        if (n == 0) return 0.0
        if (n == 1) return sortedValues[0]
        val position = (pct / 100.0) * (n - 1).toDouble()
        val lower = position.toInt()
        val upper = minOf(lower + 1, n - 1)
        val frac = position - lower.toDouble()
        return sortedValues[lower] + frac * (sortedValues[upper] - sortedValues[lower])
    }

    /**
     * Estimate a personalized HRmax from a trailing HR series.
     * Returns (hrmax bpm, source) where source ∈ {"observed", "tanaka", "unknown"}.
     */
    fun estimateHRmax(hrHistory: List<Double>, age: Double?): Pair<Double, String> {
        val n = hrHistory.size
        val tanaka = age?.let { tanakaHRmax(it) }

        if (n >= hrmaxMinSamples) {
            val observed = percentile(hrHistory.sorted(), hrmaxPercentile)
            if (tanaka == null) return observed to "observed"
            return if (observed >= tanaka) observed to "observed" else tanaka to "tanaka"
        }
        if (tanaka != null) return tanaka to "tanaka"
        return 0.0 to "unknown"
    }

    // ---- Karvonen %HRR and Edwards zone weight ----

    /** Karvonen %HRR, clamped [0, 100]. */
    fun pctHRR(bpm: Double, restingHR: Double, hrReserve: Double): Double {
        val pct = (bpm - restingHR) / hrReserve * 100.0
        if (pct < 0) return 0.0
        if (pct > 100) return 100.0
        return pct
    }

    /**
     * Edwards 5-zone weight (0–5) from %HRR (unclamped; extremes agree with
     * the clamped path at both ends).
     */
    fun zoneWeight(bpm: Double, restingHR: Double, hrReserve: Double): Int {
        val pct = (bpm - restingHR) / hrReserve * 100.0
        for ((threshold, weight) in edwardsZones) {
            if (pct >= threshold) return weight
        }
        return 0
    }

    // ---- TRIMP accumulation ----

    /**
     * Longest span (minutes) a single reading may be credited with. A wear or connection dropout leaves a
     * gap with no data in it; without a ceiling the last reading before the gap would be credited with the
     * whole of it, so one sample in zone 5 could invent hours of effort. 2 min is 4x the sparsest real
     * cadence we know of (the 5/MG's ~30 s, see [minSparseReadings]), so no genuine cadence is truncated.
     */
    const val maxSampleGapMin: Double = 2.0

    /**
     * The one Effort figure every read-out on Today must show (#1001).
     *
     * Effort has two sources. [stored] is the daily row, rewritten only when the heavy daily pass runs.
     * [live] is today's in-progress recompute over the raw HR stream (local midnight → now), which exists
     * precisely because the stored row lags — early in the day it still holds yesterday's Effort or a
     * stale 0.0 (#402). Past days have no live value and use the row.
     *
     * Taking the MAX rather than preferring [live] is not a tie-break: Effort accrues over a day and must
     * never visibly DROP. The live recompute can UNDER-read when today's HR is sparse, or when a logged
     * workout's load is not in the raw stream — a 5/MG user who trained in the morning had a real 38.3
     * replaced by a live 0 (#489/#506). Flooring at what is already earned is what stops that.
     *
     * Shared so the hero ring, the Key Metrics tile and the chart's edge badge cannot drift apart: they
     * each resolved Effort themselves, and only the ring knew about [live], so an active morning showed
     * 2.3 on the ring and 0.5 in the other two until the daily pass caught up (#1001).
     */
    fun effectiveEffort(live: Double?, stored: Double?): Double? {
        if (live == null) return stored
        if (stored == null) return live
        if (live == 0.0 && stored == 0.0) return 0.0
        return kotlin.math.max(live, stored)
    }

    /**
     * Infer per-sample duration (minutes) from the first two timestamps. Falls
     * back to 1 s when fewer than two samples or coincident timestamps.
     *
     * No production caller remains — TRIMP uses [sampleDurationsMinutes] (#950). Kept ONLY so the
     * uniform-identity regression test can compare the new accumulation against the SHIPPED old formula
     * rather than a reimplementation of it. Delete it if that test ever goes.
     */
    fun sampleDurationMinutes(hr: List<HrSample>): Double {
        if (hr.size < 2) return fallbackSampleMin
        val deltaS = abs((hr[1].ts - hr[0].ts).toDouble())
        return if (deltaS > 0) deltaS / 60.0 else fallbackSampleMin
    }

    /**
     * Per-sample durations (minutes): each reading covers the gap to the NEXT one, clamped to
     * [maxSampleGapMin]; the last reuses the gap before it.
     *
     * #950: TRIMP used to take ONE duration inferred from the first two timestamps and multiply the whole
     * zone-weight sum by it. NOOP's HR stream is not uniformly spaced — live Bluetooth arrives ~1 s apart,
     * banked 5/MG history ~30 s, and dropouts leave larger holes — so whichever gap happened to be first
     * set the scale for the entire window. Worse, a workout window and the day that contains it start at
     * different samples, so they picked different factors and the two Effort numbers stopped being
     * comparable, which is what the report was about.
     *
     * For a UNIFORMLY spaced series every gap is the same, so this returns the old value for every sample
     * and the resulting TRIMP is unchanged — which is why no existing test moves.
     */
    fun sampleDurationsMinutes(hr: List<HrSample>): List<Double> {
        if (hr.isEmpty()) return emptyList()
        if (hr.size == 1) return listOf(fallbackSampleMin)
        val out = ArrayList<Double>(hr.size)
        for (i in 0 until hr.size - 1) {
            val deltaS = abs((hr[i + 1].ts - hr[i].ts).toDouble())
            val min = if (deltaS > 0) deltaS / 60.0 else fallbackSampleMin
            out.add(kotlin.math.min(min, maxSampleGapMin))
        }
        out.add(out.last())   // the final reading has no successor; reuse the gap before it
        return out
    }

    fun edwardsTRIMP(
        hr: List<HrSample>,
        restingHR: Double,
        hrReserve: Double,
        durations: List<Double>,
    ): Double {
        var acc = 0.0
        for (i in hr.indices) {
            acc += zoneWeight(hr[i].bpm.toDouble(), restingHR, hrReserve) * durations[i]
        }
        return acc
    }

    /**
     * Minutes in each Edwards zone, indexed by the zone's own weight: `[0]` is time BELOW zone 1,
     * `[1..5]` are zones 1 to 5.
     *
     * `[0]` is the bucket no existing line can show. Edwards scores sub-50 %HRR time as exactly zero, so
     * it never reaches `trimp` and nothing downstream reports it, yet it is the quantity #2438's step 2
     * proposes to weight. `[1..5]` are the zone shares step 1 fits its weights on, readable until now
     * only from a WHOOP export rather than from what NOOP itself saw.
     *
     * Sums to the same duration TRIMP integrates over, so the six buckets and `trimp` describe exactly
     * the same time. That is CREDITED time, not wall-clock wear: [sampleDurationsMinutes] clamps each
     * reading to [maxSampleGapMin], so a ten-minute dropout contributes two minutes here. Anyone wanting
     * a wear-coverage floor (#2438 step 2) needs a different quantity, and summing these will not give
     * it to them.
     *
     * The caller must pass `hrReserve > 0`: [zoneWeight] divides by it, and the refusal path reaches this
     * line with a reserve that can be zero or negative.
     *
     * Byte-identical to the Swift twin `StrainScorer.zoneMinutes`.
     */
    fun zoneMinutes(
        hr: List<HrSample>,
        restingHR: Double,
        hrReserve: Double,
        durations: List<Double>,
    ): List<Double> {
        val out = DoubleArray(6)
        for (i in hr.indices) {
            out[zoneWeight(hr[i].bpm.toDouble(), restingHR, hrReserve)] += durations[i]
        }
        return out.toList()
    }

    fun banisterTRIMP(
        hr: List<HrSample>,
        restingHR: Double,
        hrReserve: Double,
        durations: List<Double>,
        b: Double,
        /** Per-minute rate treated as "no effort" and subtracted from EVERY sample, floored at zero
         *  (#1624). Zero — the default — is the original, unfloored Banister recipe, so every existing
         *  caller and test is byte-identical. Pass [banisterBaselineRatePerMinute] to score the excess
         *  over a sedentary day, which is what the daily scorer does.
         *
         *  Per SAMPLE, never as one lump off the total: a day quieter than the floor would otherwise run
         *  a deficit that eats into real work done on top, and 90 minutes at 35% HRR inside an otherwise
         *  still day would net negative and clamp to zero — erasing exactly the intermittent effort this
         *  recipe exists to capture. */
        floorRatePerMinute: Double = 0.0,
    ): Double {
        var acc = 0.0
        for (i in hr.indices) {
            val x = pctHRR(hr[i].bpm.toDouble(), restingHR, hrReserve) / 100.0
            if (x > 0) {
                val rate = x * banisterScale * exp(b * x)
                acc += durations[i] * (rate - floorRatePerMinute).coerceAtLeast(0.0)
            }
        }
        return acc
    }

    // ---- Logarithmic map ----

    /**
     * Map accumulated TRIMP onto [0, 100] via 100 × ln(TRIMP+1) / ln(D), 2 dp.
     * TRIMP ≤ 0 → 0, and D ≤ 1 (or NaN) → 0, being outside the map's domain. The output is
     * unbounded as D → 1⁺ — an upper clamp is tracked separately.
     *
     * The default D is **Edwards'**. A Banister TRIMP passed here without an explicit denominator is
     * scored against the wrong ceiling and reads low — prefer [strain], which resolves the method's own
     * denominator, or pass [logMapDenominator] yourself. (#1545)
     */
    fun trimpToStrain(trimp: Double, denominator: Double = strainDenominator): Double {
        if (trimp <= 0) return 0.0
        // D ≤ 1 (and NaN) is outside the map's domain: ln(1) = 0 divides to ±∞, ln(D) < 0 below 1
        // flips the sign, and ln(D) is NaN at or below 0. Out-of-domain D is no score, like
        // TRIMP ≤ 0 — before this guard D = 1 returned a saturated 9.2e16 here and +Inf on Swift
        // for the same input (the denominator-domain fix). The default 7201 is unaffected.
        if (!(denominator > 1)) return 0.0
        val value = maxStrain * ln(trimp + 1.0) / ln(denominator)
        val scaled = value * 100
        // Round in Double space: roundToLong() clips anything past Long.MAX_VALUE, which Swift's
        // .rounded() does not, so a D just above 1 still disagreed across platforms (the
        // denominator-domain fix). Above 2^53 every Double is already an integer, so passing it
        // through IS the rounded value.
        // Keep this comparison in this direction: abs(NaN) < 2^53 is false, so NaN intentionally
        // takes the pass-through; reversing it to `>= 2^53` would send NaN through `roundToLong()`,
        // collapse it to 0.0, and break parity with Swift.
        val rounded = if (abs(scaled) < 9007199254740992.0) scaled.roundToLong().toDouble() else scaled
        return rounded / 100.0
    }

    // ---- Denominator calibration ----

    /**
     * Calibrate D from (TRIMP, reference_strain) pairs via the through-origin
     * least-squares line: ln(D) = maxStrain × Σ(x²) / Σ(xy), x = ln(TRIMP+1).
     * Reference strains are on the maxStrain (0–100) scale. Throws [StrainException]
     * when fewer than 2 usable pairs (TRIMP>0, strain>0) or degenerate.
     */
    fun fitStrainDenominator(pairs: List<Pair<Double, Double>>): Double {
        val usable = pairs.filter { it.first > 0 && it.second > 0 }
        if (usable.size < 2) throw StrainException(StrainError.TOO_FEW_PAIRS)
        var sumXX = 0.0
        var sumXY = 0.0
        for ((trimp, strain) in usable) {
            val x = ln(trimp + 1.0)
            sumXX += x * x
            sumXY += x * strain
        }
        if (!(sumXY > 0 && sumXX > 0)) throw StrainException(StrainError.DEGENERATE)
        return exp(maxStrain * sumXX / sumXY)
    }

    /**
     * One line naming WHERE the day's HRmax came from, and what the day's own heart rate actually
     * reached — the pair of numbers #2438's step 0 turns on.
     *
     * The `effort score` line beside this one already reports the HRmax it used, but it can only say
     * `provided` or `default`, and `provided` is two different answers at once: a manual override, and
     * the Tanaka age formula. Those are the two the step-0 proposal treats differently ("a manual
     * override always wins"), so a contributed log cannot currently be read for it. This line splits
     * them, and carries the day's observed peak next to the formula value so the gap between the
     * yardstick a day was scored against and the one the day's own heart rate suggests is a subtraction
     * rather than an inference.
     *
     * `peak` is the day's RAW maximum, not a percentile. That is deliberate: the rule under discussion
     * counts days whose peak passed a threshold ("reached on at least two different days in the last
     * 90"), so the per-day maximum is the quantity that rule is written in, and a reader can evaluate
     * the rule from a run of these lines before anything is built. A single artefact spike is visible as
     * the one day that disagrees with its neighbours, which is the same thing the two-day requirement
     * exists to absorb.
     *
     * Changes no score. [hrmaxSource] is the branch the CALLER took, because the branch is only visible
     * there — [strain] receives an HRmax with its provenance already discarded.
     *
     * No PII: a day key and four bpm values. Byte-identical string to the Swift twin `dayCalibrationLine`.
     */
    fun dayCalibrationLine(
        day: String, hrmax: Double?, hrmaxSource: String,
        tanaka: Double?, observedPeak: Double?, restingHR: Double,
    ): String =
        // The formatters live on WorkoutDetector, where `effort bout` needed them first. Sharing them
        // rather than copying is what keeps a day line and a bout line in the same log rounding the same
        // way; a second copy would be free to drift, and these two lines are read side by side.
        "effort calib day=$day hrmax=${WorkoutDetector.round0(hrmax)}" +
            " src=$hrmaxSource tanaka=${WorkoutDetector.round0(tanaka)}" +
            " peak=${WorkoutDetector.round0(observedPeak)} rhr=${WorkoutDetector.round0(restingHR)}"

    /**
     * The ` sustained=` field appended to [dayCalibrationLine]: the same day's peak held across
     * consecutive samples ([sustainedPeak]), so a run of lines shows how much of each day's `peak` was a
     * single sample. Its own function, appended by the caller, so the calibration line's existing contract
     * stays as it is. Same formatter as the fields before it; null renders as `nil`, not 0.
     *
     * Byte-identical to the Swift twin `sustainedPeakField`.
     */
    fun sustainedPeakField(sustainedPeak: Double?): String =
        " sustained=${WorkoutDetector.round0(sustainedPeak)}"

    /** Consecutive samples a `sustained` peak must hold for, and the span they must fit in. */
    const val sustainedPeakSamples = 5
    const val sustainedPeakWindowS = 60L

    /**
     * The highest bpm that [sustainedPeakSamples] consecutive samples all reached within
     * [sustainedPeakWindowS] seconds, or null when no run of samples is that dense.
     *
     * The `sustained` field beside the raw `peak` on the `effort calib` line (#2438). On ring days the raw
     * daily maximum is nearly always one isolated sample: over 60 days of Oura heart rate it sat above the
     * age formula on 58 days, and this value on none, while 98 % of the samples at or above 165 bpm lay in
     * a ±30 s window whose median was under 120. A step-0 rule read off the raw peak would raise a ring
     * wearer's HRmax from artefacts, so contributed logs carry both, and the rule can be written against
     * whichever one holds up on straps.
     *
     * The minimum over each run, not its mean: one spike inside five ordinary samples must not lift the
     * value, which is the whole point of the field. Null rather than a fallback to the raw peak, so a sparse
     * day reads as "not measured" and not as "held".
     *
     * Byte-identical to the Swift twin `sustainedPeak`.
     */
    fun sustainedPeak(
        hr: List<HrSample>,
        samples: Int = sustainedPeakSamples,
        windowS: Long = sustainedPeakWindowS,
    ): Double? {
        if (samples <= 0 || hr.size < samples) return null
        // Ordered by (ts, bpm), not ts alone: Swift's sort is not stable and Kotlin's is, so two samples
        // sharing a second could otherwise form different runs on the two platforms.
        val sorted = hr.sortedWith(compareBy({ it.ts }, { it.bpm }))
        var best: Int? = null
        for (i in 0..(sorted.size - samples)) {
            val last = i + samples - 1
            if (sorted[last].ts - sorted[i].ts > windowS) continue
            val held = (i..last).minOf { sorted[it].bpm }
            best = maxOf(best ?: held, held)
        }
        return best?.toDouble()
    }

    /**
     * The ` span=` field appended after `sustained=`: how many seconds the run behind that value covered
     * ([sustainedPeakSpan]). Its own function, appended by the caller, like [sustainedPeakField]. Null
     * renders as `nil`, not 0.
     *
     * Byte-identical to the Swift twin `sustainedPeakSpanField`.
     */
    fun sustainedPeakSpanField(spanS: Long?): String = " span=${spanS ?: "nil"}"

    /**
     * The seconds covered by the run that sets [sustainedPeak], or null when that is null.
     *
     * [sustainedPeak] bounds a run's span from above only, so the same value can stand for five samples
     * inside four seconds of dense heart rate or across a whole minute of sparse heart rate. On one ring
     * with all-day heart rate the winning run covered 4 s on some days and 57 s on others. This field
     * carries the span beside the value, so a contributed log says which kind of hold it was.
     *
     * When several runs reach the same value, the longest span among them: the strongest evidence that
     * the value was held. Same rule and same ordering as [sustainedPeak], so the two fields always
     * describe the same run.
     *
     * Byte-identical to the Swift twin `sustainedPeakSpan`.
     */
    fun sustainedPeakSpan(
        hr: List<HrSample>,
        samples: Int = sustainedPeakSamples,
        windowS: Long = sustainedPeakWindowS,
    ): Long? {
        if (samples <= 0 || hr.size < samples) return null
        val sorted = hr.sortedWith(compareBy({ it.ts }, { it.bpm }))
        var bestHeld: Int? = null
        var bestSpan = 0L
        for (i in 0..(sorted.size - samples)) {
            val last = i + samples - 1
            val span = sorted[last].ts - sorted[i].ts
            if (span > windowS) continue
            val held = (i..last).minOf { sorted[it].bpm }
            val b = bestHeld
            if (b != null && (b > held || (b == held && bestSpan >= span))) continue
            bestHeld = held
            bestSpan = span
        }
        return if (bestHeld == null) null else bestSpan
    }

    /**
     * One line naming what an Effort score was computed FROM, or why it could not be computed.
     *
     * The gap this closes: [strain] is the only score in the app with no trace at all. WorkoutDetector,
     * SleepStager and both engines each emit a funnel; the number on the Today hero ring emitted nothing,
     * so a log could not distinguish "measured, and the day was genuinely calm" from "could not measure".
     * A reader looking for the latter finds `effort detect`, which is WORKOUT-BOUT detection and answers a
     * different question — a confusion that has already produced one wrong diagnosis.
     *
     * `enough` is the [strain] gate spelled out: dense (>= minReadings) OR sparse-but-sustained. `trimp`
     * and `strain` are absent when the gate refused, which is exactly the case a bare 0 hides.
     *
     * Swift twin: `StrainScorer.scoreFunnelLine`. Reciprocal, and phrased with the word "twin" on
     * purpose: the scanner's claim patterns require it, so a "Byte-identical to ..." sentence reads as
     * a claim to a human while the ledger sees nothing.
     */
    fun scoreFunnelLine(
        day: String,
        hrSamples: Int,
        enough: Boolean,
        maxHR: Double,
        maxHRProvided: Boolean,
        restingHR: Double,
        method: Method,
        trimp: Double?,
        strain: Double?,
        zoneMinutes: List<Double>? = null,
    ): String =
        "effort score day=$day hr=$hrSamples enough=$enough" +
            " hrMax=${round1(maxHR)}(${if (maxHRProvided) "provided" else "default"})" +
            " rhr=${round1(restingHR)} reserve=${round1(maxHR - restingHR)}" +
            " method=${method.name.lowercase()}" +
            " trimp=${trimp?.let { round1(it) } ?: "n/a"} strain=${strain?.let { round1(it) } ?: "n/a"}" +
            // Per-zone minutes, appended last so every field before this one keeps its position and the
            // existing parsers are unaffected. Absent rather than zeroed when the reserve is invalid: a
            // refused day has no zones, and six zeros would read as a day spent entirely below zone 1.
            (zoneMinutes?.takeIf { it.size == 6 }
                ?.let { z -> (0..5).joinToString("") { " z$it=${round1(z[it])}" } }
                ?: " zones=n/a")

    /** One decimal, locale-independent, so two platforms' lines compare byte for byte. */
    private fun round1(v: Double): String = String.format(java.util.Locale.US, "%.1f", v)

    // ---- Public API ----

    /**
     * Cardiovascular Effort (0–100) from an HR series. APPROXIMATE.
     *
     * Returns null when there isn't yet enough data to trust the number — fewer than [minReadings]
     * samples AND less than [minSpanSeconds] of HR coverage (the sparse-strap path, #482) — or when
     * maxHR ≤ restingHR (invalid HRR).
     *
     * @param hr time-ordered [HrSample] list.
     * @param maxHR HRmax (bpm). Defaults to 220 − defaultAge when null.
     * @param restingHR resting HR (bpm) for the HRR denominator (default 60).
     * @param method [Method.EDWARDS] (default) or [Method.BANISTER].
     * @param sex "male"/"female" — selects the Banister coefficient (ignored by Edwards).
     * @param denominator log-map D (default [strainDenominator]).
     */
    fun strain(
        hr: List<HrSample>,
        maxHR: Double? = null,
        restingHR: Double = defaultRestingHR,
        method: Method = Method.EDWARDS,
        sex: String = "male",
        // null (the default) resolves to the denominator that BELONGS to [method] — Edwards' 7201, or
        // Banister's sex-dependent ceiling. Pass a value only to override.
        denominator: Double? = null,
        // Optional diagnostic sink. Null by default and the line is built ONLY when one is supplied, so a
        // scoring pass that nobody is watching pays nothing — which matters because a pass re-scores many
        // days. Callers hand this in for the day worth explaining, not for all of them.
        diag: ((String) -> Unit)? = null,
        day: String = "",
    ): Double? {
        val resolvedDenominator = denominator ?: logMapDenominator(method, sex)
        val effMax = maxHR ?: defaultMaxHR().toDouble()
        // Enough data to trust the score: a dense stream (≥ minReadings) OR a sparse-but-sustained
        // one spanning ≥ minSpanSeconds with a sample floor (#482 — the 5/MG's ~30 s HR cadence).
        val enoughData = when {
            hr.size >= minReadings -> true
            hr.size >= minSparseReadings -> {
                val tss = hr.map { it.ts }
                (tss.maxOrNull() ?: 0L) - (tss.minOrNull() ?: 0L) >= minSpanSeconds
            }
            else -> false
        }
        if (!enoughData || effMax <= restingHR) {
            // The refusal is the half a bare number cannot show: null here and 0.0 on a calm day look
            // identical on the ring, and only one of them is a measurement.
            diag?.let {
                it(scoreFunnelLine(day, hr.size, enoughData, effMax, maxHR != null, restingHR, method,
                                   trimp = null, strain = null))
            }
            return null
        }

        val durations = sampleDurationsMinutes(hr)
        val hrReserve = effMax - restingHR

        val trimp: Double = when (method) {
            Method.BANISTER -> {
                val b = if (sex.lowercase().startsWith("f")) banisterBWomen else banisterBMen
                // Excess over the sedentary baseline for the SAME span, floored at zero. Without this a
                // desk day scores ~45 on a 0-100 axis whose bottom is supposed to be no exertion (#1624).
                banisterTRIMP(hr, restingHR, hrReserve, durations, b,
                    floorRatePerMinute = banisterBaselineRatePerMinute(b))
            }
            Method.EDWARDS -> {
                edwardsTRIMP(hr, restingHR, hrReserve, durations)
            }
        }
        val scored = trimpToStrain(trimp, resolvedDenominator)
        diag?.let {
            // Walked only inside this let, so a normal scoring pass never pays for a diagnostic nobody
            // is reading: it is a second O(n) pass and analyzeRecent's prep is already the expensive
            // half. `hrReserve` is safe here, the refusal path above already returned for
            // `effMax <= restingHR`. Emitted under BOTH methods on purpose: the zones describe what the
            // day WAS, not how it was scored, and #2438 fits an Edwards-shaped model either way.
            val zones = zoneMinutes(hr, restingHR, hrReserve, durations)
            it(scoreFunnelLine(day, hr.size, enoughData, effMax, maxHR != null, restingHR, method,
                               trimp = trimp, strain = scored, zoneMinutes = zones))
        }
        return scored
    }
}
