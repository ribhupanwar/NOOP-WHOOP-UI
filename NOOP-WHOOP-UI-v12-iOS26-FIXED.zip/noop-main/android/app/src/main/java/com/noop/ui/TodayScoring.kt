package com.noop.ui

import com.noop.R
import com.noop.analytics.BaselineState
import com.noop.analytics.Baselines
import com.noop.analytics.ChargeBaselines
import com.noop.analytics.ChargeDriver
import com.noop.analytics.RecoveryDrivers
import com.noop.analytics.RestScorer
import com.noop.analytics.ScoreConfidence
import com.noop.data.DailyMetric
import java.time.LocalDate
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

/**
 * The recovery baseline's real seed count while it still cold-starts, the honest "calibrating N of
 * <seed>" progress shown in place of "No Data"; null once recovery exists or the baseline has crossed
 * the seed gate. N is the HRV baseline's `nValid` from folding the SAME day-keyed, epoch-aware history
 * the recovery engine folds ([Baselines.foldHistory] with [hrvBaselineEpoch]), NOT a looser per-night
 * bounds count. Callers pass the Charge HRV history ([ChargeBaselines.Resolved.hrvHistory], #2525), the
 * nights the engine's fold actually reads.
 *
 * The old count advanced on every in-range night, including nights the engine's fold DROPS after a
 * manual "Recalibrate HRV baseline" (each night dated before the epoch is discarded, not skip-and-held).
 * A genuinely-calibrating user who had >= seed old in-range nights therefore read `count >= seed -> null`,
 * and the Today score side fell through to [ScoreState.NeedsStrap] while the post-recalibration baseline
 * was still seeding (Bug B, #393 follow-up). `nValid` is the exact count Baselines.computeStatus gates
 * CALIBRATING on, so N now tracks the baseline the Charge ring rides and can never over-state it.
 * [nightlyHrv] and [dayKeys] are parallel and oldest->newest (same order the engine folds). Mirrors the
 * Swift `RecoveryScorer.calibrationNights`. Pure + unit-tested (RecoveryCalibrationTest). (PR #85)
 */
internal fun recoveryCalibrationNights(
    nightlyHrv: List<Double?>,
    dayKeys: List<String>,
    hasRecovery: Boolean,
    hrvBaselineEpoch: Double,
    seed: Int = Baselines.minNightsSeed,
): Int? {
    if (hasRecovery) return null
    val n = Baselines.foldHistory(nightlyHrv, dayKeys, Baselines.hrvCfg, hrvBaselineEpoch).nValid
    // Include 0: a brand-new user (no banked nights) reads "Calibrating, 0 of N" on Charge, not a
    // bare "No data" that looks broken (#335). Caller gates past days to null; >= seed -> null.
    return n.takeIf { it in 0 until seed }
}

/**
 * The ordered "What shaped it" Charge driver rows for [displayDay], scored against [baselines], the
 * Charge baselines [AppViewModel.chargeBaselines] resolves with the engine's own rule (#2525), so the bars
 * describe the baseline the Charge ring was scored against. Before #2525 this folded the whole visible
 * history itself, which kept every imported night and every stored own night while the headline kept only
 * the recent own nights plus the import, so the page could show one baseline in the rows and score against
 * another. (#2315 had already closed the same gap for the recalibration epoch; the resolver applies both
 * epochs.) Defers to [RecoveryDrivers.chargeDrivers], which scores each row against the SAME inputs
 * [RestScorer] reads through the Today recovery path. Empty when the displayed day can't score (cold-start /
 * missing input / no baselines yet), so the section hides rather than faking rows. Mirrors the iOS
 * `ChargeBreakdownWiring.breakdown`.
 */
internal fun recoveryChargeDrivers(
    baselines: ChargeBaselines.Resolved?,
    displayDay: DailyMetric?,
): List<ChargeDriver> {
    val resolved = baselines ?: return emptyList()
    val day = displayDay ?: return emptyList()
    val hrv = day.avgHrv ?: return emptyList()
    val rhr = day.restingHr?.toDouble() ?: return emptyList()

    val hrvBase = resolved.hrv
    if (!hrvBase.usable) return emptyList()
    // Passed on ungated, unlike respBase below, and that is deliberate since #1988: chargeDrivers
    // gates this one itself, for its score AND for the row it builds from the baseline directly.
    // Gating again here would be harmless but would suggest the callee does not, which it does.
    val rhrBase = resolved.restingHR
    val respBase = resolved.resp.takeIf { it.usable }

    // sleepPerf: the Rest COMPOSITE (/100) when stages exist, else raw efficiency, the SAME derivation
    // recomputeRecovery uses, so the Sleep driver scores against the headline's own input.
    val sleepPerf = RestScorer.restFromDaily(day)?.let { it / 100.0 } ?: day.efficiency

    return RecoveryDrivers.chargeDrivers(
        hrv = hrv,
        rhr = rhr,
        resp = day.respRateBpm,
        hrvBaseline = hrvBase,
        rhrBaseline = rhrBase,
        respBaseline = respBase,
        sleepPerf = sleepPerf,
        skinTempDev = day.skinTempDevC,
    )
}

/**
 * The Charge (recovery) [ScoreConfidence] tier for [displayDay] against the HRV baseline in [baselines],
 * surfaced as the confidence dot + tier tag under the "What shaped it" rows. SURFACED, never recomputed
 * differently: it calls [ScoreConfidence.forCharge] with the SAME HRV baseline the drivers scored against.
 * Before the first resolve it reads an empty fold, exactly as an empty history did. Mirrors the iOS
 * surfacing of the existing ScoreConfidence on the recovery screen.
 */
internal fun chargeConfidenceTier(
    baselines: ChargeBaselines.Resolved?,
    displayDay: DailyMetric?,
): ScoreConfidence {
    val hrvBase: BaselineState = baselines?.hrv ?: Baselines.foldHistory(emptyList(), Baselines.hrvCfg)
    return ScoreConfidence.forCharge(displayDay?.recovery, hrvBase)
}

/**
 * The most recent fully-SCORED recovery day to carry over on TODAY while tonight's recovery hasn't been
 * scored yet (#543), the ONE prior row every recovery-derived read-out (Charge ring, HRV / resting-HR /
 * respiratory / SpO2 tiles, Synthesis, Contributors, Readiness) carries over from at the rollover. Pure +
 * unit-tested (TodayMetricTilesTest). [days] is oldest->newest; the chosen row is the last with a non-null
 * recovery that isn't today's (still-null) [selectedDayKey]. Returns null unless it's today, today itself
 * isn't scored, and we're not mid-calibration (calibration owns its own copy), so past days / a scored
 * today / a calibrating today carry nothing and live behaviour is unchanged. Mirrors iOS.
 */
internal fun lastScoredRecoveryDay(
    days: List<DailyMetric>,
    selectedDayKey: String,
    isToday: Boolean,
    todayScored: Boolean,
    isCalibrating: Boolean,
    // #547 carry-over guard: the local "today" key ("yyyy-MM-dd"). A stray FUTURE-dated row (a bad strap
    // clock wrote a day past today) must NEVER be picked as "last night", that's how #547's Today header
    // read "12 Jul". Cheap belt-and-suspenders alongside the ingest gate + heal: filter candidates to
    // day <= today so even a future row that slipped through can't surface here. ISO date keys sort
    // chronologically, so a plain string compare is correct. Defaulted to MAX so an un-updated call site
    // keeps the prior behaviour; the Today call site passes the real local today.
    today: String = "9999-12-31",
): DailyMetric? {
    if (!isToday || todayScored || isCalibrating) return null
    return days.lastOrNull { it.recovery != null && it.day != selectedDayKey && it.day <= today }
}

/** A prior day's Charge carried over on TODAY (value + "Last night · <date>" caption) while tonight's
 *  recovery hasn't been scored yet (#543). Mirrors the iOS lastScoredCharge tuple. */
internal data class LastCharge(val value: Double, val caption: String)

/** "d MMM" for a stored `yyyy-MM-dd` day key, used by the carried-over Charge caption (#543). Parses
 *  the key and falls back to the raw key so the caption is never empty. Mirrors iOS lastChargeDateFmt. */
internal fun lastChargeDateLabel(dayKey: String): String =
    runCatching {
        LocalDate.parse(dayKey).format(DateTimeFormatter.ofPattern("d MMM", Locale.getDefault()))
    }.getOrDefault(dayKey)

/** Carry-over recency cap (#779): the "Last night" framing only holds when the carried scored day is
 *  within this many days of today. Mirrors iOS TodayView.carryFreshnessDays. */
internal const val CARRY_FRESHNESS_DAYS = 2L

/** True when the carried scored day is OLDER than the freshness cap (#779), which drives the "Latest
 *  sleep" relabel. Pure + unit-testable. Both keys are "yyyy-MM-dd"; an unparseable key (or non-positive gap)
 *  reads as fresh so we never over-claim staleness. [today] is today's key (carry-over is today-only),
 *  defaulted to the device's current date for the composable call sites. Mirrors iOS isCarryStale. */
internal fun isCarryStale(priorDayKey: String, today: String = LocalDate.now().toString()): Boolean =
    runCatching {
        ChronoUnit.DAYS.between(LocalDate.parse(priorDayKey), LocalDate.parse(today)) > CARRY_FRESHNESS_DAYS
    }.getOrDefault(false)

/** #977 - HONEST Rest resolution for the selected day. Today's own scored Rest wins; otherwise, ONLY on
 *  today, tail-fall-back to the last scored night, but ONLY when that night is within the carry-freshness
 *  window ([isCarryStale] == false). A live 5.0 whose sleep never scores (no overnight gravity => no
 *  `sleep_performance` point ever written) used to pin Rest to a weeks-old scored night while Charge kept
 *  advancing; gating the tail-fallback lets the Rest ring fall through to its needs-a-tracked-night state
 *  instead of freezing on a stale number. The legitimate morning carry of last night's Rest (before today
 *  scores) is preserved unchanged. Pure + unit-testable. Mirrors iOS TodayView.freshRestScore. */
internal fun freshRestScore(
    todayValue: Double?, lastDay: String?, lastValue: Double?,
    isTodaySelected: Boolean, today: String = LocalDate.now().toString(),
): Double? {
    if (todayValue != null) return todayValue
    if (!isTodaySelected || lastDay == null || lastValue == null) return null
    return if (isCarryStale(lastDay, today)) null else lastValue
}

/** The carried recovery caption stamp, keyed on that scored day's own date and its recency. Within the
 *  freshness cap it reads "Last night · <date>"; once the carried day is older than the cap (#779) it reads
 *  "Latest sleep · <date>" so a weeks-old import is never surfaced as "Last night". Shared by every carried
 *  recovery read-out so the prior-day provenance reads identically. Mirrors iOS carriedCaption. */
internal fun carriedCaption(priorDayKey: String, today: String = LocalDate.now().toString()): DisplayText =
    DisplayText.Resource(
        if (isCarryStale(priorDayKey, today)) R.string.score_state_title_latest_sleep
        else R.string.score_state_title_last_night,
        listOf(lastChargeDateLabel(priorDayKey)),
    )

// Explainability layer, COMPONENTS 2, 3, 4 (spec: 2026-06-20-sleep-guidance-explainability.md)
//
// "No bare number without a STATE, a REASON, and a NEXT STEP." Every uncertain or derived read-out on
// Today gets a clear state, a plain-English reason and a next step, and we NEVER fabricate a number:
// calibrating / needs-strap show NO value, carried values are always stamped with their date, and the
// provenance badge reflects the REAL per-day merge winner. The copy here is VERBATIM and must match the
// Swift today lane word-for-word (ScoreState / RecordingState). No em-dashes anywhere.

/**
 * The honest state of one score/tile on Today, one state per score, never a bare blank. Derived from
 * baseline readiness + data presence + the #543 carry-over, so a tile that has no own value for the day
 * still says WHY and WHAT to do, and shows no fabricated number. Mirrors Swift `ScoreState` 1:1 (same
 * three cases, same [title] / [detail] copy). [Scored] carries the real value the tile renders normally;
 * the other three are the no-own-number states this layer explains.
 */
sealed class ScoreState {
    /** Today's own value exists, the tile renders the number as usual; this layer adds nothing. */
    data class Scored(val value: Double) : ScoreState()

    /** Baselines still cold-start: [nightsRemaining] more nights of wear until scores get personal.
     *  Shows NO number (calibrating never fakes a value). */
    data class Calibrating(val nightsRemaining: Int) : ScoreState()

    /** A prior scored day shown before tonight is scored (#543 carry-over), stamped with [dateLabel]
     *  ("d MMM") so the prior read is never passed off as today's. [stale] is true when that day is older
     *  than the freshness cap (#779): the carry is still shown so the recovery side isn't a bare blank, but
     *  it's relabelled "Latest sleep" so a weeks-old import is never passed off as "Last night". */
    data class CarriedLastNight(val dateLabel: String, val stale: Boolean = false) : ScoreState()

    /** No data for today at all, strap not worn / not connected / not synced. Shows NO number. */
    object NeedsStrap : ScoreState()

    val titleRes: Int?
        get() = when (this) {
            is Scored -> null
            is Calibrating -> R.string.score_state_title_calibrating
            is CarriedLastNight -> if (stale) R.string.score_state_title_latest_sleep else R.string.score_state_title_last_night
            NeedsStrap -> R.string.score_state_title_needs_strap
        }

    val detailRes: Int?
        get() = when (this) {
            is Scored -> null
            is Calibrating -> R.plurals.score_state_detail_calibrating
            is CarriedLastNight -> if (stale) R.string.score_state_detail_carried_stale else R.string.score_state_detail_carried_fresh
            NeedsStrap -> R.string.score_state_detail_needs_strap
        }

    /**
     * #731: names WHY the countdown restarted when the user tapped "Recalibrate baseline".
     *
     * The count alone is not enough. A reporter sat at "Calibrating, 3 of 4 nights" with 15 valid HRV
     * nights on file and tapped Recalibrate again — which discards every earlier night and resets the
     * count to 0. Two weeks of that and Charge could never return. Seeing the countdown without knowing
     * their own tap caused it makes re-tapping the natural move; naming the cause breaks the loop.
     *
     * A separate whole sentence, not a fragment stitched onto the countdown. Returns null when no
     * recalibration is set, so the card is unchanged for every user who never tapped it. Pure.
     * Twin of Swift `ChargeBreakdownFormat.calibrationRestartCause`.
     */
    companion object {
        /** The recalibration epoch (seconds) as a short display day ("19 Jul"), or null when none is
         *  set. Pure - the caller reads the pref. Twin of Swift
         *  `ChargeBreakdownFormat.recalibrationDay(epoch:)`; uses the same "d MMM" pattern as the
         *  sibling day formatter in this file. (#731) */
        fun recalibrationDay(epochSeconds: Long): String? {
            if (epochSeconds <= 0L) return null
            return Instant.ofEpochSecond(epochSeconds)
                .atZone(ZoneId.systemDefault())
                .toLocalDate()
                .format(DateTimeFormatter.ofPattern("d MMM", Locale.getDefault()))
        }

        internal fun calibrationRestartCause(recalibratedOn: String?): DisplayText? = recalibratedOn
            ?.takeIf { it.isNotEmpty() }
            ?.let { DisplayText.Resource(R.string.today_calibration_restart_cause, listOf(it)) }
    }
}

/**
 * Resolve the honest [ScoreState] for the Today score side from the same signals the tiles already use,
 * so the explainer is the EXACT truth on screen (never a separate guess). Pure + unit-tested. Order of
 * precedence mirrors the tile waterfall:
 *   1. [todayRecovery] present                -> [ScoreState.Scored] (the tile shows its real number);
 *   2. mid-calibration ([calibratingNights])  -> [ScoreState.Calibrating] (N more nights, no number);
 *   3. a prior scored day to carry (#543)     -> [ScoreState.CarriedLastNight] (stamped with its date);
 *   4. otherwise                              -> [ScoreState.NeedsStrap] (no data, no number).
 * Mirrors Swift `scoreStateForToday`.
 */
internal fun scoreStateForToday(
    todayRecovery: Double?,
    calibratingNights: Int?,
    carriedDay: DailyMetric?,
    seed: Int = Baselines.minNightsSeed,
    today: String = LocalDate.now().toString(),
): ScoreState = when {
    todayRecovery != null -> ScoreState.Scored(todayRecovery)
    // "About N more nights" = the seed gate minus the nights banked so far, floored at 1 (zero would read
    // as "ready" when it isn't). Calibrating never fakes a value.
    calibratingNights != null -> ScoreState.Calibrating((seed - calibratingNights).coerceAtLeast(1))
    // #779: a carry older than the freshness cap is still shown (not a bare blank) but relabelled to
    // "Latest sleep" so a weeks-old import is never passed off as "Last night".
    carriedDay != null -> ScoreState.CarriedLastNight(lastChargeDateLabel(carriedDay.day), isCarryStale(carriedDay.day, today))
    else -> ScoreState.NeedsStrap
}

/**
 * #1164/#2012 — should today's Rest be MARKED provisional? When the strap has banked records not yet
 * offloaded, the Rest score is computed from partial data and may change once the full night lands and
 * `analyzeRecent` re-scores it. Saying so reads honestly instead of as a bug when the number moves.
 *
 * True means "caption it as pending", NOT "hide it". #2012: the number used to be withheld on both
 * surfaces while this was true, so a user whose night was scored saw nothing for as long as the strap
 * had anything left to send, which on a continuously banking strap is most of the day. A number that
 * may still move is not the same as no number, and it is the one the screen exists to show.
 *
 * Two honest signals, either of which means more data is expected:
 * - [backfilling]: an offload is actively running right now (data is draining).
 * - [historyPendingSync]: the strap reports banked records newer than our local frontier (the strap has
 *   data we haven't ingested yet, even when no offload is running — e.g. right after connect, before
 *   the first offload starts).
 *
 * Only applies to TODAY (a past day's score is final — no more data is coming for it) and only when a
 * Rest score EXISTS (pending annotates a score; it never fabricates one where there is none). Pure +
 * unit-tested. Mirror EXACTLY of Swift `TodayView.restPendingSync`.
 */
internal fun restPendingSync(
    restScore: Double?,
    backfilling: Boolean,
    historyPendingSync: Boolean,
    isTodaySelected: Boolean,
): Boolean {
    if (!isTodaySelected || restScore == null) return false
    return backfilling || historyPendingSync
}

/**
 * The honest live-recording state of the strap. Derived from the BLE connection and last-sync
 * timestamp. Mirrors Swift `RecordingState` (same cases, [title] / [detail] copy, and [tone]).
 * Android Today has no recording-status chip; the scan control is its current connection affordance.
 */
sealed class RecordingState {
    /** The strap is connected and saving data live. */
    object Recording : RecordingState()

    /** Not live now, but synced [minutesAgo] minutes ago, an honest "how fresh is it". */
    data class LastSynced(val minutesAgo: Long) : RecordingState()

    /** No connection and nothing recent to fall back on. */
    object NotRecording : RecordingState()

    /** #580, a connected WHOOP 5/MG streaming live HR fine, but its firmware hands over no history
     *  offload yet. NOT the WHOOP-4 "not recording" failure: the link is live, history sync is just
     *  experimental on 5.0. Surfaced from `LiveState.historySyncExperimental`, overriding the resolver. */
    object HistoryExperimental : RecordingState()

    /** #612, connected with no live HR AND no evidence data is actually flowing — either this is the
     *  strap's first-ever pairing (never once synced) or a WHOOP-4/generic strap whose last several
     *  offloads all came back empty ([LiveState.sustainedEmptyOffload]). Distinct from [NotRecording]:
     *  the link genuinely IS up, so claiming "Strap not connected" would be false. */
    object ConnectedNoData : RecordingState()

    val titleRes: Int
        get() = when (this) {
            Recording -> R.string.recording_chip_title_recording
            is LastSynced -> R.string.recording_chip_title_last_synced
            NotRecording -> R.string.recording_chip_title_not_recording
            HistoryExperimental, ConnectedNoData -> R.string.recording_chip_title_connected
        }

    val detailRes: Int
        get() = when (this) {
            Recording -> R.string.recording_chip_detail_recording
            is LastSynced -> R.string.recording_chip_detail_last_synced
            NotRecording -> R.string.recording_chip_detail_not_recording
            HistoryExperimental -> R.string.recording_chip_detail_history_experimental
            ConnectedNoData -> R.string.recording_chip_detail_connected_no_data
        }

    /** Chip hue: live recording reads positive (gold/green dot), a stale-but-recent sync reads neutral,
     *  not-recording reads critical so a dropped link is obvious; the 5.0 experimental-history state and
     *  the connected-no-data state are both connected so they read accent, not critical. */
    val tone: StrandTone
        get() = when (this) {
            Recording -> StrandTone.Positive
            is LastSynced -> StrandTone.Neutral
            NotRecording -> StrandTone.Critical
            HistoryExperimental -> StrandTone.Accent
            ConnectedNoData -> StrandTone.Accent
        }
}

/**
 * Resolve the honest [RecordingState] from the live BLE state + last-sync timestamp. Pure + unit-tested.
 *   - connected AND a live HR is streaming  -> [RecordingState.Recording] (it really is saving data);
 *   - connected, no live HR, AND (never synced OR [sustainedEmptyOffload]) -> [RecordingState.ConnectedNoData]
 *                                              (#612 — the link IS up, so "not connected" would be false);
 *   - else a [lastSyncAtSec] this session    -> [RecordingState.LastSynced] (minutes since, clamped >= 0,
 *                                              ROUNDED UP so a 30s-old sync reads "1m ago" not "0m ago");
 *   - else                                   -> [RecordingState.NotRecording].
 * "Recording" requires BOTH a connection AND a live heart-rate sample so a bonded-but-silent link can't
 * claim it's saving data. [nowSec] is unix seconds (injected so the math is testable). Mirrors Swift
 * `RecordingState.resolve`.
 */
internal fun recordingStateFor(
    connected: Boolean,
    liveHeartRate: Int?,
    lastSyncAtSec: Long?,
    nowSec: Long,
    sustainedEmptyOffload: Boolean = false,
): RecordingState = when {
    connected && liveHeartRate != null -> RecordingState.Recording
    connected && liveHeartRate == null && (lastSyncAtSec == null || sustainedEmptyOffload) ->
        RecordingState.ConnectedNoData
    lastSyncAtSec != null -> {
        // Clamp at 0 (a sync stamped slightly in the future from strap-clock skew can't read negative)
        // then ROUND UP so a 30-second-old sync reads "1m ago", never "0m ago", matches the Swift
        // `RecordingState.resolve` ceil. ceil(secs / 60) == (secs + 59) / 60 for non-negative longs.
        val secs = (nowSec - lastSyncAtSec).coerceAtLeast(0L)
        RecordingState.LastSynced((secs + 59L) / 60L)
    }
    else -> RecordingState.NotRecording
}

/** #245: the sync-status state the Today top bar's `SyncStatusChip` composable renders. Mirrors Swift
 *  `SyncChipState` 1:1 (same four cases, same priority order) so the twin can't drift on WHEN to show
 *  what. THREE non-hidden states so the ABSENCE of active syncing reads as "caught up", not "missing
 *  indicator": actively offloading -> [Syncing]; idle with a known last-sync -> [Synced]; a 5/MG whose
 *  history sync is experimental (live-connected, no completed offload yet) -> [ExperimentalLive].
 *  [Hidden] only on a true cold start (the building-scores note owns that case). Previously this
 *  priority order lived inline inside the `@Composable`, where it could not be unit-tested. */
sealed class SyncChipState {
    /** #689/#815 follow-up: [pagesBehind] is the strap's GET_DATA_RANGE ring backlog, sampled ONCE at
     *  connect (`LiveState.pagesBehindAtConnect`) and never re-polled, so it is a figure "at connect"
     *  rather than a live one — the copy says so. null when no reply has landed this session, when the
     *  frame did not decode, AND when the backlog is zero: a chip that is actively syncing while
     *  claiming "0 pages behind" contradicts itself, and a zero sample carries nothing a reader can
     *  act on. [resolve] applies that rule so both platforms drop the same case. */
    data class Syncing(val chunks: Int, val pagesBehind: Int? = null) : SyncChipState()
    data class Synced(val agoText: String) : SyncChipState()
    object ExperimentalLive : SyncChipState()
    object Hidden : SyncChipState()

    companion object {
        /** Pure + unit-tested. Mirrors Swift `SyncChipState.resolve` exactly: backfilling wins over a
         *  known last-sync, which wins over the 5/MG experimental fallback.
         *
         *  [nowSec] (unix seconds) is a PARAMETER rather than something this function reaches for, which
         *  is what keeps "pure" true — same injected-clock style as [recordingStateFor] just above.
         *
         *  There used to be a `nowLabel` parameter too, carrying the already-translated "now" word for the
         *  `< 60s` branch, because resolving it in here goes through `NoopApplication` and throws under a
         *  plain JVM unit test (no Robolectric, so no Application is ever attached). #1472 removed the
         *  word itself — see [shortSyncAgo] — so there is no lookup left to inject, and this signature now
         *  matches Swift's. */
        fun resolve(
            backfilling: Boolean,
            chunks: Int,
            lastSyncAtSec: Long?,
            historySyncExperimental: Boolean,
            nowSec: Long,
            pagesBehind: Int? = null,
        ): SyncChipState = when {
            // `takeIf { it > 0 }` is the zero rule from [Syncing.pagesBehind], applied here so the
            // decision is pure and testable rather than sitting in the composable. Negative can't come
            // off the wire (the decoder returns a ring delta), but the bound reads the same either way.
            backfilling -> Syncing(chunks, pagesBehind?.takeIf { it > 0 })
            lastSyncAtSec != null -> Synced(shortSyncAgo(lastSyncAtSec, nowSec))
            historySyncExperimental -> ExperimentalLive
            else -> Hidden
        }
    }
}

/** Compact relative age for the header chip ("<1m" / "Nm" / "Nh" / "Nd") from a unix-SECONDS timestamp —
 *  deliberately terse, and now wordless in every branch.
 *
 *  EVERY branch must read correctly with a trailing "ago", because the chip's accessibility description
 *  wraps it in "Strap history synced %1$s ago". The sub-minute branch used to return the translated word
 *  "now", which read "Strap history synced now ago" to a screen reader (#1472). "<1m" composes, and being
 *  digits and symbols it needs no catalog entry in any language — which is what let the `nowLabel`
 *  parameter and its string resource go. [nowSec] is unix seconds, injected to keep this pure.
 *  Mirrors the iOS `SyncChipState.shortAgo`. */
internal fun shortSyncAgo(unixSec: Long, nowSec: Long): String {
    val secs = (nowSec - unixSec).coerceAtLeast(0)
    return when {
        secs < 60 -> "<1m"
        secs < 3600 -> "${secs / 60}m"
        secs < 86_400 -> "${secs / 3600}h"
        else -> "${secs / 86_400}d"
    }
}

/** Whether this night's sleep staging is low-confidence, using the core [ScoreConfidence] rule. */
internal fun restStageLowConfidence(d: DailyMetric?): Boolean {
    val asleepMin = d?.totalSleepMin ?: return false
    val efficiency = d.efficiency ?: return false
    val restorativeMin = (d.deepMin ?: 0.0) + (d.remMin ?: 0.0)
    val hasStaged = restorativeMin > 0.0
    if (ScoreConfidence.forRest(hasSession = true, hasStagedSleep = hasStaged) != ScoreConfidence.SOLID) {
        return false
    }
    return ScoreConfidence.forRest(
        hasSession = true,
        hasStagedSleep = hasStaged,
        asleepSeconds = asleepMin * 60.0,
        restorativeSeconds = restorativeMin * 60.0,
        efficiency = efficiency,
    ) == ScoreConfidence.BUILDING
}

/** Short "it's coming, not broken" caption for an unscored tile on today only. */
internal fun buildingHint(metric: KeyMetric, isToday: Boolean): Int? {
    if (!isToday) return null
    return when (metric) {
        KeyMetric.REST -> R.string.today_building_wear_tonight
        KeyMetric.EFFORT -> R.string.today_building_moves_with_you
        KeyMetric.CHARGE -> R.string.today_building_wear_tonight
        KeyMetric.BLOOD_OXYGEN -> R.string.today_building_wear_tonight
        KeyMetric.STEPS -> R.string.today_building_moves_with_you
        else -> null
    }
}

/**
 * #1599: which series the Blood Oxygen tile plots — the calibrated one, or the strap candidate.
 *
 * `AnalyticsEngine` writes `spo2Pct = null` on every computed day and banks the raw red/IR ADC instead,
 * so a calibrated reading only ever arrives from an IMPORT. On a strap-only install [calibrated] is empty
 * by construction, and the tile drew a value above a blank panel while every neighbour had a line.
 *
 * Gated on whether a series can be DRAWN, not on whether a value exists. The Apple tile asks the latter
 * (`spo2.value == "—" && candidateTail != nil`), and that misses the case this issue was actually
 * reported from: one old imported reading carries the tile's VALUE forward indefinitely, so the value is
 * never "—", so the swap never fires — while the 14-day window it would have to plot still holds nothing.
 * A number with no line, which is the bug. The sparkline's question is "have I got two points", so that
 * is what decides it.
 *
 * Falls back to [calibrated] when NEITHER can be drawn, so a tile with no data anywhere behaves exactly
 * as it did — nothing is drawn, and nothing is invented to fill the space.
 */
internal fun spo2SparkSeries(
    calibrated: List<Double>,
    candidate: List<Double>,
): List<Double> = if (calibrated.size >= 2 || candidate.size < 2) calibrated else candidate

/**
 * True when the tile's VALUE is the strap estimate rather than a measured reading, so the caption can
 * say so.
 *
 * Deliberately about the value, not the line: the caption renders directly under the number, so it must
 * describe the number. The two can differ — an unbounded carry can keep a measured value on a tile whose
 * window has only estimates to plot — and in that case the value is captioned honestly and the line's
 * provenance goes unlabelled, which is the lesser of the two silences available.
 */
internal fun spo2UsingCandidate(calibratedValue: Double?, candidateToday: Double?): Boolean =
    calibratedValue == null && candidateToday != null
