#if os(iOS)
import Foundation
import HealthKit
import WhoopProtocol
import CoreLocation
import UIKit
import WhoopStore
import StrandAnalytics
import StrandImport

/// Two-way Apple Health bridge for the iOS app.
///
/// iOS has HealthKit (macOS does not), so the iOS target can do far more than parse a static export:
/// it reads the user's own Health data live and maps it onto the **same** `WhoopStore` rows the
/// macOS importer produces (under the `apple-health` source id), and it writes NOOP-computed metrics
/// back into Apple Health. Everything stays on-device and strictly opt-in.
@MainActor
final class HealthKitBridge: ObservableObject {

    enum AuthState: Equatable {
        case unknown, unavailable, denied, authorized
        /// The build can't talk to HealthKit at all: it was re-signed (free Apple ID / AltStore /
        /// Sideloadly) WITHOUT the `com.apple.developer.healthkit` entitlement, so the framework is
        /// present but the app can never read/write Health and can never appear under
        /// Settings › Health › Data Access & Devices. Distinct from `.denied` (entitled build, user
        /// said no) and `.unavailable` (no HealthKit hardware) so the UI can route to the honest
        /// file/Shortcuts import path instead of giving impossible Settings instructions (#348).
        case entitlementMissing
    }

    @Published private(set) var auth: AuthState = .unknown
    @Published private(set) var lastSync: Date?
    @Published private(set) var syncing = false
    /// Coalesces a fresh-data notification that arrives while another HealthKit pass owns the bridge.
    /// Without this, a strap offload finishing during the foreground read/write pass was deferred until
    /// the next app open even though the newly-banked rows were already available locally.
    private var writeBackPending = false
    /// How many days the last COMPLETED sync covered, so an observer wake can tell whether a sync that
    /// just ran already read its window. Paired with `lastSync` (the time). Reset to 0 by a failed sync,
    /// so a failure never lets a later wake be skipped on the strength of it.
    private var lastSyncDays = 0
    /// How long an observer wake will accept a just-completed sync instead of running its own.
    ///
    /// Six sample types carry `enableBackgroundDelivery(frequency: .hourly)`, and two of them —
    /// `.heartRate` and `.activeEnergyBurned` — get new samples continuously on a worn Apple Watch, so in
    /// practice several observers wake within moments of each other every hour. Each wake used to run a
    /// FULL sync: ~15 HealthKit aggregate queries plus a write-back, no matter which type woke it.
    ///
    /// Scoping the queries to the woken type is NOT an option: the rows are upserted with
    /// `ON CONFLICT DO UPDATE SET x = excluded.x` on every column, a full replace, so a sync that skipped
    /// a query would write NULL over that day's stored value and wipe it. Coalescing is safe instead
    /// because it changes nothing about what a sync reads — it only declines to repeat one.
    ///
    /// Skipping is lossless: `sync` re-reads AGGREGATES for a window, so a sync that already covered this
    /// wake's days has ingested its samples. The anchor exists only to name the window (see
    /// `fetchTouchedDayWindow`), which is why it is still advanced on a skip.
    ///
    /// The Android side has had this shape all along — `syncHealthConnectIfStale` gates its Health Connect
    /// import on a staleness interval. This brings iOS in line.
    private static let observerCoalesceWindow: TimeInterval = 15 * 60
    /// The most recent failure surfaced by `sync` / `writeBack`. Cleared on a successful run. UI binds
    /// here so an Apple Health auth revoke, quota hit, or invalid sample is visible instead of silent.
    @Published private(set) var lastError: String?

    private let store = HKHealthStore()
    private let repo: Repository
    /// Source id imported HealthKit data lands under (matches `AppModel.appleDeviceId`).
    private let appleDeviceId: String
    /// NOOP's own strap-derived source id, read back when writing into Health.
    private let noopDeviceId: String
    /// NOOP's on-device COMPUTED daily scores (recovery/HRV/RHR/SpO₂/resp) live under the sibling
    /// `deviceId + "-noop"` id — mirrors `Repository.computedDeviceId` / `IntelligenceEngine.computedId`.
    /// `writeBack` must read this, not the raw import id: a Bluetooth-only WHOOP user has no imported
    /// `noopDeviceId` daily row, so those metrics exist ONLY here.
    private var computedDeviceId: String { noopDeviceId + "-noop" }

    init(repo: Repository, appleDeviceId: String, noopDeviceId: String) {
        self.repo = repo
        self.appleDeviceId = appleDeviceId
        self.noopDeviceId = noopDeviceId
        // Order matters: a free-signed build with no HealthKit entitlement is dead in the water even
        // where the hardware supports Health, so surface that first. `.unavailable` (no HealthKit at
        // all, e.g. iPad without the framework) still wins where it applies because we only reach the
        // entitlement check when `isHealthDataAvailable()` is true.
        if !HKHealthStore.isHealthDataAvailable() {
            auth = .unavailable
        } else if !HealthKitBridge.hasHealthKitEntitlement {
            auth = .entitlementMissing
        }
    }

    // MARK: - Types

    private var readTypes: Set<HKObjectType> {
        var s = Set<HKObjectType>()
        for id in HealthKitBridge.quantityReadIds { if let t = HKObjectType.quantityType(forIdentifier: id) { s.insert(t) } }
        if let sleep = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) { s.insert(sleep) }
        s.insert(HKObjectType.workoutType())
        // #1205: workout routes (GPS) so imported workouts can show their map. Routes are separate
        // samples associated with each HKWorkout; without this in readTypes the route query returns
        // empty and the imported workout shows distance but no map — same as today, so the addition
        // is strictly additive.
        s.insert(HKSeriesType.workoutRoute())
        return s
    }

    private var writeTypes: Set<HKSampleType> {
        var s = Set<HKSampleType>()
        for id in HealthKitBridge.quantityWriteIds + HealthKitBridge.highResQuantityWriteIds
            where !HealthKitBridge.writeDenied.contains(id) {
            if let t = HKObjectType.quantityType(forIdentifier: id) { s.insert(t) }
        }
        if let sleep = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) { s.insert(sleep) }
        s.insert(HKObjectType.workoutType())
        s.insert(HKSeriesType.workoutRoute())
        return s
    }

    // Every id here ends up in the HealthKit permission dialog. Only request what `sync` actually
    // aggregates into `DayAgg`; adding read scopes the app never consumes makes the consent prompt
    // noisier and surfaces a privacy ask we don't honour.
    private static let quantityReadIds: [HKQuantityTypeIdentifier] = [
        .heartRate, .restingHeartRate, .heartRateVariabilitySDNN, .oxygenSaturation,
        .respiratoryRate, .bodyTemperature, .stepCount, .activeEnergyBurned,
        .basalEnergyBurned, .vo2Max,
        // Body composition — READ-ONLY (#20). Imported under the apple-health source like the file
        // importer already ingests; deliberately NOT in quantityWriteIds (we never write these back).
        .bodyMass, .bodyFatPercentage, .leanBodyMass, .bodyMassIndex,
        // Water — READ-ONLY (#949), so drinks logged in a dedicated hydration app (or by a smart bottle)
        // show up without being typed in twice. Lands in the hydration source rather than apple-health,
        // because the hydration screen is what consumes it. Never written back.
        .dietaryWater,
        // Caffeine — READ-ONLY (#949). Feeds the caffeine window's decay estimate, which already stores
        // time + optional mg per intake, so a Health sample maps onto it directly. Apple exposes this as
        // its own narrow type; Health Connect has no caffeine-only scope (caffeine is a field on
        // NutritionRecord, behind READ_NUTRITION — the whole food log), which is why Android is not
        // matched here. Never written back.
        .dietaryCaffeine
    ]
    private static let quantityWriteIds: [HKQuantityTypeIdentifier] = [
        .restingHeartRate, .heartRateVariabilitySDNN, .oxygenSaturation, .respiratoryRate
    ]
    /// Identifiers that must NEVER enter a `requestAuthorization(toShare:)` set, filtered out of every
    /// write set below (#1366). HealthKit reserves some quantity types to Apple Watch —
    /// `.appleSleepingWristTemperature`, the only type that fits a worn wrist skin temperature, is one —
    /// and asking to SHARE such a type does not fail softly: it raises an uncatchable ObjC
    /// `NSInvalidArgumentException` ("Authorization to share the following types is disallowed") that
    /// terminates the app on launch (verified on device, iOS 27). Swift `try/catch` cannot intercept an
    /// `NSException`, so the ONLY defense is to keep read-only ids out of the share set. Filtering here
    /// makes that structural: a read-only id added to a write list by mistake is dropped from the ask
    /// instead of bricking launch, turning a ship-and-crash into a no-op.
    private static let writeDenied: Set<HKQuantityTypeIdentifier> = [.appleSleepingWristTemperature]
    // High-res write-back shares: the continuous 1-minute HR stream, and the energy/distance samples
    // attached to written workouts. Kept separate from the four nightly-vital ids so the permission
    // expansion and each independently-authorized writer remain explicit.
    private static let highResQuantityWriteIds: [HKQuantityTypeIdentifier] = [
        .heartRate, .activeEnergyBurned, .distanceWalkingRunning, .distanceCycling
    ]

    // MARK: - Authorization

    /// UserDefaults key holding the authorization set the user was last asked about.
    /// Retains the old key so an existing read-only fingerprint triggers one expanded request.
    private static let readTypeSignatureKey = "noop.health.readTypeSignature"

    /// UserDefaults key gating the one-time 90-day hourly-step backfill (see the hourly collection
    /// below). Set once the first hourly-step HealthKit query actually returns rows; every later
    /// `sync()` only walks the same window the daily collectors already use.
    private static let hourlyStepsBackfilledKey = "applehealth.hourlySteps.backfilled"

    /// Fingerprint the actual read and share sets, including categories and series (#2644).
    /// Keep the roles distinct: adding share access for an already-readable type must change it.
    /// `writeTypes` applies `writeDenied`, so forbidden share types never expand the request.
    private var authorizationTypeSignature: String {
        let reads = readTypes.map { "read:" + $0.identifier }
        let writes = writeTypes.map { "write:" + $0.identifier }
        return (reads + writes).sorted().joined(separator: ",")
    }

    private func persistAuthorizationTypeSignature() {
        UserDefaults.standard.set(authorizationTypeSignature, forKey: Self.readTypeSignatureKey)
    }

    /// Re-request authorization when the app adds a read or share type (#949, #2644).
    ///
    /// HealthKit never reports read authorization. Without a refresh, a read type added in an update
    /// stays unrequested for everyone who granted access before it existed, and its queries return
    /// empty forever — indistinguishable from "you have
    /// no water in Health", and silent. Water and caffeine would have done nothing at all for every
    /// existing user, which is most of them.
    ///
    /// The same gap affects newly-added write types: their writers require `.sharingAuthorized`.
    /// Comparing a stored fingerprint of both sets catches either expansion. Re-requesting is quiet:
    /// HealthKit presents the sheet ONLY for types that are still undetermined, so a user whose set is
    /// unchanged sees no UI, and a returning user is asked about exactly the new ones. The signature is
    /// stored only on success, so a failed request is retried rather than silently swallowed.
    private func requestNewAuthorizationTypesIfNeeded() async {
        // FOREGROUND only. `sync` is also driven by background observer wakes, and asking there would
        // spend the one request we get where no sheet can be presented — if that call reported success
        // without showing anything, the signature would be stored and the user never asked at all.
        guard auth == .authorized,
              UIApplication.shared.applicationState == .active,
              UserDefaults.standard.string(forKey: HealthKitBridge.readTypeSignatureKey)
                  != authorizationTypeSignature
        else { return }
        do {
            try await store.requestAuthorization(toShare: writeTypes, read: readTypes)
            persistAuthorizationTypeSignature()
        } catch {
            // Leave the signature unset so the next sync tries again. Not surfaced in `lastError`: the
            // user did not ask for this, and the rest of the sync is unaffected.
        }
    }

    /// Request read + write permission. HealthKit never reveals whether *read* was granted, so we
    /// treat a successful request as `.authorized` and let queries return empty if the user declined.
    func requestAuthorization() async {
        guard HKHealthStore.isHealthDataAvailable() else { auth = .unavailable; return }
        // A free-signed build (no `com.apple.developer.healthkit` entitlement) can NEVER reach Health:
        // `requestAuthorization` either throws "Missing application-identifier"/"missing entitlement"
        // or returns without ever presenting the sheet and leaves every type `.notDetermined`. Either
        // way the honest answer is "this build can't use Apple Health directly", NOT "you denied it" —
        // so never fall through to `.denied` (which tells the user to fix it in Settings, where the app
        // can never appear). Detect via the embedded provisioning profile up front (#348).
        guard HealthKitBridge.hasHealthKitEntitlement else { auth = .entitlementMissing; return }
        do {
            try await store.requestAuthorization(toShare: writeTypes, read: readTypes)
            // The entitlement is present (the guard above proved it via the embedded profile, or there's
            // no profile = App Store build), so a successful request means the bridge is usable. We do
            // NOT reclassify to `.entitlementMissing` off the post-request `.notDetermined` heuristic
            // here: on a genuinely-entitled build the user could grant only reads (writes stay
            // `.notDetermined`) or dismiss the share sheet, and that must stay `.authorized` with the
            // normal Settings guidance — never the file-import reroute. The provisioning-profile check is
            // the authoritative signal; the `.notDetermined` fallback only matters when that check can't
            // run, which on iOS means an App Store build that by definition has the entitlement.
            auth = .authorized
            // Record the current read and share sets — see `requestNewAuthorizationTypesIfNeeded`.
            persistAuthorizationTypeSignature()
        } catch {
            // A thrown error here is on a build that carries the entitlement (guarded above), so it's a
            // genuine denial / request failure — keep the normal `.denied` "enable in Settings" path,
            // never the entitlement-missing reroute.
            auth = .denied
        }
        // First successful grant in this process: arm the live HealthKit stream so a watch-only user
        // gets continuous ingestion (new SDNN/RHR/sleep/etc. land within the hour) instead of only on
        // app foreground. Guarded inside enableLiveDelivery on auth == .authorized, so the .denied path
        // above is a no-op.
        enableLiveDelivery()
    }

    /// Resume a prior grant on launch without re-prompting. `auth` is a fresh `.unknown` every
    /// process (the bridge isn't persisted), so a user who already enabled Apple Health would
    /// otherwise have to re-tap "Enable" each session before the scenePhase sync runs. HealthKit
    /// never reveals *read* status, but *write*/share status is observable — if the user already
    /// authorized all of our write types, treat the bridge as `.authorized`. This only reads
    /// status, so no system permission sheet is shown.
    func refreshAuthIfPreviouslyGranted() {
        guard auth == .unknown, HKHealthStore.isHealthDataAvailable() else { return }
        // Share authorization is per type. Resume when at least one write type is granted so a person
        // who intentionally declined (for example) workouts still gets sleep/vitals exported after a
        // relaunch. Requiring every legacy type made partial grants look wholly disconnected.
        let granted = writeTypes.contains { store.authorizationStatus(for: $0) == .sharingAuthorized }
        if granted {
            auth = .authorized
            // A returning user who already granted access should get the live stream re-armed for this
            // process. enableLiveDelivery is idempotent (HealthKit dedups observers + background
            // delivery per type), so calling it here as well as after a fresh requestAuthorization is safe.
            enableLiveDelivery()
            // The high-res write-back added share types (HR stream, workouts, energy/distance) that a
            // pre-update grant has as `.notDetermined`. Re-request once: HealthKit shows a single sheet
            // listing ONLY the new types, and each write feature independently guards on its own type's
            // share status, so declining any checkbox just skips that feature.
            // Raw request, NOT requestAuthorization(): that method reclassifies a thrown error as
            // `.denied`, which must never demote a bridge that just resumed a valid legacy grant.
            //
            // FOREGROUND only, for the same reason `requestNewAuthorizationTypesIfNeeded` is: this resume is now
            // also called from the offload write-back (#1021), which runs in processes that were never
            // foregrounded. Asking there would spend the one request we get where no sheet can be
            // presented. The status read above is unaffected, so a legacy grant still resumes.
            let newTypesPending = writeTypes.contains { store.authorizationStatus(for: $0) == .notDetermined }
            if newTypesPending, UIApplication.shared.applicationState == .active {
                Task { try? await store.requestAuthorization(toShare: writeTypes, read: readTypes) }
            }
        }
    }

    // MARK: - Live delivery (continuous ingestion)

    /// The QUANTITY types we want a live observer + hourly background delivery on. This is the subset of
    /// `quantityReadIds` that actually feeds Charge/Rest/Effort/Fitness Age, so a watch-only user's numbers
    /// refresh on their own rather than only when the app is foregrounded. `enableLiveDelivery` observes
    /// these plus sleep and workouts; this list is not the whole observed set.
    /// We deliberately do NOT observe the body-composition reads (weight/BMI/etc.) — those don't move a
    /// score and a manual weigh-in shouldn't wake the app every hour.
    private static let liveQuantityIds: [HKQuantityTypeIdentifier] = [
        .heartRateVariabilitySDNN, .restingHeartRate, .activeEnergyBurned, .heartRate, .vo2Max
    ]

    /// Long-lived observer queries, retained so HealthKit doesn't tear them down. Keyed by the sample
    /// type's identifier so a second `enableLiveDelivery()` call replaces rather than duplicates.
    private var observerQueries: [String: HKObserverQuery] = [:]

    /// Register one `HKObserverQuery` per scored read type and turn on hourly background delivery, so
    /// new Apple Watch data is ingested continuously. Each observer's update handler runs an anchored
    /// delta sync of just the affected window and then calls HealthKit's completion handler (required —
    /// HealthKit stops delivering to an observer that never acknowledges). Idempotent and guarded behind
    /// `auth == .authorized`; safe to call from several entry points.
    func enableLiveDelivery() {
        guard auth == .authorized, HKHealthStore.isHealthDataAvailable() else { return }

        var types: [HKSampleType] = []
        for id in HealthKitBridge.liveQuantityIds {
            if let t = HKObjectType.quantityType(forIdentifier: id) { types.append(t) }
        }
        if let sleep = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) { types.append(sleep) }
        // Workouts, for the same reason the scored reads are here: without an observer a Watch workout
        // reached NOOP only at the next foreground open, or whenever an unrelated type happened to wake
        // the app, so up to an hour late and sometimes longer (#2265).
        //
        // The lag is not only cosmetic. A strap offload can score, detect a bout and write it to Apple
        // Health entirely in the background while the Watch workout covering the same session is still
        // unknown here, so the overlap check that would have suppressed that bout has nothing to compare
        // against, and the wearer is asked to confirm a session the Watch already recorded.
        //
        // Nothing else needs widening: the loop below is already over `HKSampleType`, and
        // `collectWorkouts` already filters on `notNoopAuthored`, so a workout THIS app wrote cannot wake
        // it into re-importing its own row.
        //
        // This NARROWS the race rather than closing it. An observer wake is not instantaneous, so an
        // offload that completes inside the wake latency still sees no Apple workout. Whether HealthKit
        // honours background delivery on `workoutType` at the quantity-type cadence is also unverified,
        // and unverifiable off-device: HealthKit has no simulator support.
        types.append(HKObjectType.workoutType())

        for type in types {
            let key = type.identifier
            // Tear down a prior observer for this type before re-registering, so a re-arm (e.g. a
            // returning user hitting both requestAuthorization and refreshAuthIfPreviouslyGranted) can
            // never leave two live observers fighting over the same completion handler.
            if let existing = observerQueries[key] {
                store.stop(existing)
                observerQueries[key] = nil
            }
            let observer = HKObserverQuery(sampleType: type, predicate: nil) { [weak self] _, completion, _ in
                // HealthKit invokes this on a background queue. Hop to the main actor (the bridge is
                // @MainActor and `sync` mutates published state), run the incremental catch-up, then
                // ALWAYS call completion so HealthKit keeps delivering. We don't tie completion to sync
                // success: a transient store error shouldn't make HealthKit think we never handled the
                // update and back off — the next foreground catch-up will reconcile.
                guard let self else { completion(); return }
                Task { @MainActor in
                    await self.syncFromObserver(type: type)
                    completion()
                }
            }
            store.execute(observer)
            observerQueries[key] = observer

            // Hourly is the finest cadence HealthKit honours for most types and is plenty for daily
            // aggregate scores. Failure here is non-fatal: the foreground catch-up still backfills.
            store.enableBackgroundDelivery(for: type, frequency: .hourly) { _, _ in }
        }
    }

    /// Drive an incremental sync off an observer wake. We use an `HKAnchoredObjectQuery` per type to
    /// learn the span of days touched since we last looked (persisting the anchor so the same samples
    /// aren't walked twice and nothing between wakes is missed), then re-aggregate just that day window
    /// via the existing `sync(days:)` path. Re-aggregating the window (rather than the deltas alone)
    /// keeps every per-day average correct and idempotent — `sync` upserts are keyed by day.
    private func syncFromObserver(type: HKSampleType) async {
        guard auth == .authorized else { return }
        // #1578: counted before any early return, so the ratio of wakes to syncs is honest. Coalescing
        // cuts the work per wake, not the wakes — this is what shows whether the wake itself is the cost.
        HealthSyncStats.recordWake()
        let (touched, newAnchor) = await fetchTouchedDayWindow(type: type)
        // No new samples since the last anchor (a spurious wake): nothing to ingest, so advancing the
        // anchor now loses nothing and skips a redundant re-query next wake.
        guard let touched else {
            HealthSyncStats.recordEmptyWake()
            if let newAnchor { persistAnchor(newAnchor, for: type) }
            return
        }
        let cal = Calendar.current
        let daysBack = cal.dateComponents([.day], from: cal.startOfDay(for: touched),
                                          to: cal.startOfDay(for: Date())).day ?? 0
        // Clamp to a sane window: at least today, and never re-walk more than a month from one wake.
        let window = max(1, min(31, daysBack + 1))
        // A sync completed moments ago and covered at least this wake's window, so a second full pass
        // would burn ~15 HealthKit aggregate queries and a write-back to re-derive rows that sync just
        // wrote. Stand down. This is what collapses the hourly burst of observers into one sync (seven of
        // them since workouts joined the set, #2265 — a count worth not restating as a literal again).
        // FOREGROUND catch-up deliberately does not consult this: an explicit resume should always read.
        // `age >= 0` is not defensive noise. This is WALL-CLOCK time, and it can move backwards — an NTP
        // correction, or a user changing the date. A negative age satisfies `< window`, so every wake would
        // skip; and because `lastSync` is only written by a sync that RAN, the skipping would keep it stale
        // and background Health ingestion would stay dead until a foreground catch-up (which ignores this
        // gate) broke the loop. Cheap to exclude, so exclude it.
        let sinceLastSync = lastSync.map { Date().timeIntervalSince($0) }
        if let age = sinceLastSync, age >= 0, age < Self.observerCoalesceWindow,
           window <= lastSyncDays {
            HealthSyncStats.recordCoalesced()
            // Deliberately do NOT advance the anchor here. Samples that landed AFTER that sync's reads but
            // before this wake are not in the store yet, and advancing past them would leave them to be
            // picked up only incidentally — by whatever later sync happens to re-read the same day. Leaving
            // the anchor put means the next wake sees the same window and syncs it for certain. The cost is
            // one more delta query on that wake, which is the cheap half; the ~15 aggregate reads and the
            // write-back are what this is avoiding.
            return
        }
        // Advance the anchor ONLY after the ingestion commits (@bhelm). If sync() bails (another sync holds
        // `syncing`, or the store is unavailable), the anchor stays put so the next wake re-fetches this
        // window and re-ingests — sync re-reads aggregates, so the replay is idempotent.
        if await sync(days: window), let newAnchor {
            persistAnchor(newAnchor, for: type)
        }
    }

    /// Advance this type's stored anchor over any new samples and return the OLDEST sample date seen,
    /// or nil when there were no new samples. Anchors are persisted in UserDefaults per type so live
    /// deltas are neither re-ingested nor missed across launches. We don't consume the samples here —
    /// `sync(days:)` re-reads the aggregate for the affected window — the anchor's only job is to tell
    /// us how far back the change reached.
    private func fetchTouchedDayWindow(type: HKSampleType) async -> (oldest: Date?, newAnchor: HKQueryAnchor?) {
        let key = HealthKitBridge.anchorDefaultsKey(for: type)
        let priorAnchor: HKQueryAnchor? = {
            guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
            return try? NSKeyedUnarchiver.unarchivedObject(ofClass: HKQueryAnchor.self, from: data)
        }()

        // Observer ingestion already caps its re-aggregation window at 31 days. Match that bound
        // here so a fresh anchor does not decode years of Watch samples that cannot be ingested by
        // this path. Explicit historical imports keep their existing query windows, and anchors
        // still advance only after the corresponding aggregate sync commits.
        let cal = Calendar.current
        guard let oldestRelevant = cal.date(byAdding: .day, value: -31,
                                            to: cal.startOfDay(for: Date())) else { return (nil, nil) }
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForSamples(withStart: oldestRelevant, end: nil, options: []),
            Self.notNoopAuthored,
        ])
        return await withCheckedContinuation { (cont: CheckedContinuation<(Date?, HKQueryAnchor?), Never>) in
            let q = HKAnchoredObjectQuery(
                type: type, predicate: predicate,
                anchor: priorAnchor, limit: HKObjectQueryNoLimit
            ) { _, samples, _, newAnchor, _ in
                // Return the advanced anchor but do NOT persist it here: the caller commits it only after
                // the ensuing sync has actually stored the window (@bhelm). Persisting in this callback,
                // before ingestion was known to run, advanced the cursor past samples a later-bailed
                // sync() never stored — silently losing days for the background/watch-only path.
                let oldest = (samples ?? []).map { $0.startDate }.min()
                cont.resume(returning: (oldest, newAnchor))
            }
            store.execute(q)
        }
    }

    /// Commit a type's advanced HealthKit anchor to UserDefaults. Called only once the sync that consumes
    /// the window has committed (or when there was nothing to ingest), so a bailed sync leaves the prior
    /// anchor in place for the next observer wake to re-fetch. Skips a nil-archive rather than clobber a
    /// good cursor. (@bhelm)
    private func persistAnchor(_ anchor: HKQueryAnchor, for type: HKSampleType) {
        guard let data = try? NSKeyedArchiver.archivedData(withRootObject: anchor, requiringSecureCoding: true) else { return }
        UserDefaults.standard.set(data, forKey: HealthKitBridge.anchorDefaultsKey(for: type))
    }

    /// UserDefaults key for a type's persisted HealthKit anchor. Namespaced so it can't collide with
    /// other app defaults, and keyed by the stable HK identifier so it survives across launches.
    private static func anchorDefaultsKey(for type: HKSampleType) -> String {
        "hkAnchor.v1.\(type.identifier)"
    }

    // MARK: - Read → store

    /// Pull the last `days` of Apple Health into the on-device store under the `apple-health` source,
    /// then write NOOP's own computed metrics back into Health. Safe to call repeatedly (idempotent
    /// upserts keyed by day).
    @discardableResult
    func sync(days: Int = 30) async -> Bool {
        guard auth == .authorized else { return false }
        guard !syncing else {
            // A full sync includes write-back. If new strap data is landing concurrently, guarantee one
            // final write-only reconciliation after the current owner releases the bridge.
            writeBackPending = true
            return false
        }
        syncing = true
        // #1578: time the whole pass — the ~15 aggregate reads, the upserts and the write-back. Recorded in
        // `defer` so an early or thrown exit still contributes; a pass that cost time and then failed is
        // exactly the one a drain report needs to show.
        let passStart = Date()
        defer {
            HealthSyncStats.recordSync(millis: Int(Date().timeIntervalSince(passStart) * 1000))
            finishHealthPass()
        }
        // Before syncing: pick up any read or share type this version added (#949, #2644).
        // No-op once the stored signature matches, which is every sync after the first.
        await requestNewAuthorizationTypesIfNeeded()
        guard let store = await repo.storeHandle() else { return false }

        let cal = Calendar.current
        let end = Date()
        guard let start = cal.date(byAdding: .day, value: -days, to: cal.startOfDay(for: end)) else { return false }

        var byDay: [String: DayAgg] = [:]
        func agg(_ day: String) -> DayAgg { byDay[day] ?? DayAgg() }
        // #2561 follow-up: every aggregate below feeds an upsert that writes `column = excluded.column`,
        // so a nil from a FAILED read replaces a stored value instead of recording an absence. Each read
        // records its own outcome here and the whole write is held back if any of them failed, because a
        // partial write cannot say which columns it is entitled to overwrite.
        var failedReads: [String] = []
        func note(_ outcome: HealthRead, _ label: String) {
            if outcome == .failed { failedReads.append(label) }
        }

        // Quantity aggregates per day.
        let restingHeartRateRead = await collect(.restingHeartRate, unit: HKUnit.count().unitDivided(by: .minute()), start: start, end: end, op: .discreteAverage) { day, v in
            var a = agg(day); a.restingHr = v; byDay[day] = a
        }
        note(restingHeartRateRead, "restingHeartRate")
        let heartRateAvgRead = await collect(.heartRate, unit: HKUnit.count().unitDivided(by: .minute()), start: start, end: end, op: .discreteAverage) { day, v in
            var a = agg(day); a.avgHr = v; byDay[day] = a
        }
        note(heartRateAvgRead, "heartRateAvg")
        let heartRateMaxRead = await collect(.heartRate, unit: HKUnit.count().unitDivided(by: .minute()), start: start, end: end, op: .discreteMax) { day, v in
            var a = agg(day); a.maxHr = v; byDay[day] = a
        }
        note(heartRateMaxRead, "heartRateMax")
        let heartRateVariabilitySDNNRead = await collect(.heartRateVariabilitySDNN, unit: .secondUnit(with: .milli), start: start, end: end, op: .discreteAverage) { day, v in
            var a = agg(day); a.hrv = v; byDay[day] = a
        }
        note(heartRateVariabilitySDNNRead, "heartRateVariabilitySDNN")
        let oxygenSaturationRead = await collect(.oxygenSaturation, unit: .percent(), start: start, end: end, op: .discreteAverage) { day, v in
            var a = agg(day); a.spo2 = v * 100; byDay[day] = a   // 0…1 → percent
        }
        note(oxygenSaturationRead, "oxygenSaturation")
        let respiratoryRateRead = await collect(.respiratoryRate, unit: HKUnit.count().unitDivided(by: .minute()), start: start, end: end, op: .discreteAverage) { day, v in
            var a = agg(day); a.respRate = v; byDay[day] = a
        }
        note(respiratoryRateRead, "respiratoryRate")
        let stepsReadOk = await collect(.stepCount, unit: .count(), start: start, end: end, op: .cumulativeSum) { day, v in
            var a = agg(day); a.steps = v; byDay[day] = a
        }
        // Steps is in the ledger as well as behind its own guard below. The guard returns first and so
        // wins the message, but recording it here is what keeps steps covered if that early return is
        // ever removed: the general guard then catches it instead of it silently losing its protection.
        note(stepsReadOk, "stepCount")
        // A failed query is not an empty step history. Stop before upserting AppleDaily: its conflict
        // update replaces the stored count with nil when another Health metric populated that day.
        // The next foreground or observer sync can retry without losing the last good reading.
        guard stepsReadOk != .failed else {
            lastSyncDays = 0
            lastError = String(localized: "Apple Health sync failed: \(String(localized: "Steps"))")
            return false
        }
        let activeEnergyBurnedRead = await collect(.activeEnergyBurned, unit: .kilocalorie(), start: start, end: end, op: .cumulativeSum) { day, v in
            var a = agg(day); a.activeKcal = v; byDay[day] = a
        }
        note(activeEnergyBurnedRead, "activeEnergyBurned")
        let basalEnergyBurnedRead = await collect(.basalEnergyBurned, unit: .kilocalorie(), start: start, end: end, op: .cumulativeSum) { day, v in
            var a = agg(day); a.basalKcal = v; byDay[day] = a
        }
        note(basalEnergyBurnedRead, "basalEnergyBurned")
        let vo2MaxRead = await collect(.vo2Max, unit: HKUnit(from: "ml/kg*min"), start: start, end: end, op: .discreteAverage) { day, v in
            var a = agg(day); a.vo2max = v; byDay[day] = a
        }
        note(vo2MaxRead, "vo2Max")

        // Body composition — READ-ONLY import under the apple-health source (#20). Weight, lean mass
        // and BMI are point-in-time readings, so take the latest-of-day; body-fat reads fine as a
        // daily average. Body-fat HealthKit gives a 0…1 fraction, scaled to percent like spo2 above.
        let bodyMassRead = await collect(.bodyMass, unit: .gramUnit(with: .kilo), start: start, end: end, op: .discreteMostRecent) { day, v in
            var a = agg(day); a.weightKg = v; byDay[day] = a
        }
        note(bodyMassRead, "bodyMass")
        let bodyFatPercentageRead = await collect(.bodyFatPercentage, unit: .percent(), start: start, end: end, op: .discreteAverage) { day, v in
            var a = agg(day); a.bodyFatPct = v * 100; byDay[day] = a   // 0…1 → percent
        }
        note(bodyFatPercentageRead, "bodyFatPercentage")
        let leanBodyMassRead = await collect(.leanBodyMass, unit: .gramUnit(with: .kilo), start: start, end: end, op: .discreteMostRecent) { day, v in
            var a = agg(day); a.leanMassKg = v; byDay[day] = a
        }
        note(leanBodyMassRead, "leanBodyMass")
        let bodyMassIndexRead = await collect(.bodyMassIndex, unit: .count(), start: start, end: end, op: .discreteMostRecent) { day, v in
            var a = agg(day); a.bmi = v; byDay[day] = a
        }
        note(bodyMassIndexRead, "bodyMassIndex")

        // Water logged in other apps (#949). A cumulative day SUM, like steps — HealthKit re-adds every
        // sample in the day on each sync, so the figure this produces is a full replacement rather than a
        // delta, which is exactly what `setImportedHydration` wants. `notNoopAuthored` (applied inside
        // `collect`) keeps NOOP's own drinks out, so a tap in NOOP can never come back as an import.
        //
        // The result is KEPT here, unlike every aggregate above: the write below replaces the stored
        // figure, so a failed query must not be mistaken for an authoritative zero and wipe the window.
        let waterReadOk = await collect(.dietaryWater, unit: .literUnit(with: .milli),
                                        start: start, end: end, op: .cumulativeSum) { day, v in
            var a = agg(day); a.waterMl = v; byDay[day] = a
        }

        // Sleep minutes per day (asleep stages summed; attributed to wake day).
        await collectSleep(start: start, end: end) { day, asleepMin, deepMin, remMin, coreMin in
            var a = agg(day)
            a.asleepMin = asleepMin; a.deepMin = deepMin; a.remMin = remMin; a.coreMin = coreMin
            byDay[day] = a
        }

        // #2561 follow-up: hold the whole write back if ANY aggregate read failed. Every upsert below
        // assigns `column = excluded.column`, so writing now would replace each failed metric's stored
        // value with the nil standing in for it. Steps had this guard already; the rest did not, and the
        // clobber is identical for activeKcal, basalKcal, vo2max, avgHr, maxHr and weightKg.
        //
        // The whole pass is held rather than the failed columns dropped, because these rows are built
        // from one `byDay` and the upserts take whole rows: there is no way to say "leave that column
        // alone" without a per-column mask the store does not have. A held pass loses nothing, since the
        // next foreground or observer sync re-reads the same window.
        guard failedReads.isEmpty else {
            lastSyncDays = 0
            lastError = String(localized: "Apple Health sync failed: \(failedReads.joined(separator: ", "))")
            return false
        }

        // Build + upsert the store rows under the apple-health source.
        let appleRows = byDay.map { (day, a) in
            AppleDaily(day: day, steps: a.steps.map { Int($0) },
                       activeKcal: a.activeKcal, basalKcal: a.basalKcal, vo2max: a.vo2max,
                       avgHr: a.avgHr.map { Int($0.rounded()) }, maxHr: a.maxHr.map { Int($0.rounded()) },
                       walkingHr: nil, weightKg: a.weightKg)
        }
        let dmRows = byDay.map { (day, a) in
            DailyMetric(day: day, totalSleepMin: a.asleepMin, efficiency: nil,
                        deepMin: a.deepMin, remMin: a.remMin, lightMin: a.coreMin, disturbances: nil,
                        restingHr: a.restingHr.map { Int($0.rounded()) }, avgHrv: a.hrv,
                        recovery: nil, strain: nil, exerciseCount: nil,
                        spo2Pct: a.spo2, skinTempDevC: nil, respRateBpm: a.respRate,
                        avgSdnn: a.hrv)   // Apple's HRV IS SDNN — mirror it into the SDNN field too
        }
        // Flatten to the generic metricSeries the shared Apple Health screen, the Today apple-health
        // sparklines, and the Metric Explorer read from — repo.series(key:source:"apple-health")
        // queries ONLY metricSeries, so without this every tile/chart renders "—" after a successful
        // sync. Reuse the importer's canonical key mapping so the keys match the macOS path exactly.
        // Body composition (weight/body_fat/lean_mass/bmi) now reads live on iOS (#20) and flows
        // through the same metricPoints keys as the file importer. iOS still doesn't collect
        // awake/in-bed minutes, so those stay nil and emit no points — correct.
        let aggregates = byDay.map { (day, a) in
            AppleDailyAggregate(
                day: day,
                restingHr: a.restingHr,
                hrvSDNN: a.hrv,
                spo2Pct: a.spo2,
                respRate: a.respRate,
                avgHr: a.avgHr,
                maxHr: a.maxHr,
                steps: a.steps,
                activeKcal: a.activeKcal,
                basalKcal: a.basalKcal,
                vo2max: a.vo2max,
                weightKg: a.weightKg,
                bodyFatPct: a.bodyFatPct,
                leanMassKg: a.leanMassKg,
                bmi: a.bmi,
                asleepMin: a.asleepMin,
                deepMin: a.deepMin,
                remMin: a.remMin,
                coreMin: a.coreMin
            )
        }
        let points = AppleHealthAggregator.metricPoints(aggregates)
            .map { MetricPoint(day: $0.day, key: $0.key, value: $0.value) }

        // Workouts the user logged in Apple Health (Apple Watch rings, gym apps, etc.). macOS already
        // imports these from a static Health export and Android reads them from Health Connect; iOS now
        // reads them live on-device too, so the platforms reach parity. ON-DEVICE ONLY: this is a plain
        // HealthKit read of workouts NOOP did NOT author, never any cloud/3rd-party API. (#835)
        let workoutRows = await collectWorkouts(start: start, end: end)

        // Persist all the apple-health rows AND write back, advancing lastSync only when the WHOLE
        // round-trip succeeds. The three read-side upserts used to be swallowed by `try?`, so a failed
        // import (e.g. a disk-full GRDB write) dropped rows yet still cleared lastError and advanced
        // lastSync — a false "success", and the next delta sync skipped the window. (Reimplemented
        // from @vulnix0x4's PR #375.)
        do {
            try await store.upsertAppleDaily(appleRows, deviceId: appleDeviceId)
            try await store.upsertDailyMetrics(dmRows, deviceId: appleDeviceId)
            try await store.upsertMetricSeries(points, deviceId: appleDeviceId)
            if !workoutRows.isEmpty { try await store.upsertWorkouts(workoutRows, deviceId: appleDeviceId) }
            // Imported water (#949) goes to the hydration source, not apple-health, because the hydration
            // screen is what reads it. Every day in the window is written — including the ones with no
            // water at all, as 0 — so deleting a drink in the source app takes it away here on the next
            // sync instead of stranding the old figure. `byDay` only holds days that had SOME metric, so
            // the zero-fill has to come from the date range rather than from its keys.
            //
            // Gated on the hydration toggle, which is opt-in and default OFF: an import must not quietly
            // populate a feature the user has turned off, and skipping it avoids writing a window of rows
            // nothing will read.
            if waterReadOk == .read, UserDefaults.standard.bool(forKey: HydrationStore.enabledKey) {
                var waterByDay: [String: Double] = [:]
                var cursor = cal.startOfDay(for: start)
                while cursor <= end {
                    waterByDay[HealthKitBridge.dayString(cursor)] = 0
                    guard let next = cal.date(byAdding: .day, value: 1, to: cursor) else { break }
                    cursor = next
                }
                for (day, a) in byDay { if let ml = a.waterMl { waterByDay[day] = ml } }
                await repo.setImportedHydration(waterByDay)
            }
            // Imported caffeine (#949) — only the last `CaffeineLogStore.retentionHours`, because the
            // store prunes past that on load and the decay estimate is long dead by then. Reading the
            // full 30-day sync window would hand over hundreds of samples for them all to be dropped.
            //
            // The caffeine card is manual-first and shows nothing until something is logged, so unlike
            // hydration there is no separate opt-in toggle to gate on: an empty Health cupboard still
            // leaves the card exactly as quiet as it is today.
            if let caffeineStart = cal.date(byAdding: .hour,
                                            value: -Int(CaffeineLogStore.retentionHours), to: end) {
                // nil means the READ failed; only an actual empty result is allowed to clear the set.
                if let imported = await collectCaffeine(start: caffeineStart, end: end) {
                    CaffeineLogStore.shared.replaceImported(imported)
                }
            }
            // Hourly step counts (v38-apple-step-hour). `appleDaily.steps` above flattens a whole day to
            // one total, so an hour the phone spent dead/on a desk is invisible — the day just reads low.
            // Walk the same window at HOURLY granularity into `appleStepHour` so a UI can show the shape
            // of the day. First run ever (flag unset) widens to 90 days back: HealthKit keeps hourly
            // statistics historically, so this answers PAST days retroactively rather than only from the
            // day it ships; later syncs re-cover the normal start...end window like the daily collectors.
            //
            // Collected HERE (not earlier) so a transient HealthKit error throws into the existing catch
            // below and the backfill flag is never set — a failed first run retries next sync instead of
            // permanently skipping the one-time 90-day widen.
            let hourlyStepsBackfilled = UserDefaults.standard.bool(forKey: Self.hourlyStepsBackfilledKey)
            let hourlyStepsStart: Date = hourlyStepsBackfilled ? start
                : (cal.date(byAdding: .day, value: -90, to: cal.startOfDay(for: end)) ?? start)
            let hourlySteps = try await collectHourlySteps(start: hourlyStepsStart, end: end)
            // Only mark the backfill done once hourly data actually lands. HealthKit returns EMPTY (not
            // an error) when step read-access is denied, and users grant Health scopes incrementally — so
            // gating on non-empty, not merely on no-throw, stops a deny-then-grant sequence from burning
            // the one-time 90-day widen before the user ever authorises steps. A genuinely step-less
            // window just re-scans next sync: cheap, bounded, self-healing.
            if !hourlySteps.isEmpty {
                try await store.upsertAppleStepHours(hourlySteps, deviceId: appleDeviceId)
                if !hourlyStepsBackfilled {
                    UserDefaults.standard.set(true, forKey: Self.hourlyStepsBackfilledKey)
                }
            }
            try await writeBack(whoopStore: store)
            lastSync = Date()
            // Record the window alongside the time: an observer wake may only stand down for a sync that
            // actually covered ITS days (see `observerCoalesceWindow`). Set on the success path only.
            lastSyncDays = days
            lastError = nil
            return true
        } catch {
            // A failed sync must never let a later wake skip on the strength of it — the rows it would
            // have written are not there. Clearing the window means `window <= lastSyncDays` cannot hold.
            lastSyncDays = 0
            lastError = String(localized: "Apple Health sync failed: \(error.localizedDescription)")
            return false
        }
    }

    /// Write-back only, for when fresh strap data lands (#1021).
    ///
    /// `sync` is the two-way pass and runs on foreground entry, which is the wrong moment: the same
    /// scenePhase block kicks the strap offload, so the write raced the data it was meant to publish and
    /// last night's sleep only reached Health on the NEXT app open. `AppModel.refreshAfterCompletedBackfill`
    /// is the real "new data landed" signal - the same one #980 already publishes the widget from - and it
    /// also fires for a backfill that completes while the app is backgrounded.
    ///
    /// Deliberately not `sync()`: that would re-read 30 days out of Health and re-run the hydration /
    /// caffeine imports on every offload, to write the same rows. The Android twin is the same shape -
    /// `WhoopBleClient` calls `HealthConnectWriter.write` after the backfill, not a full re-sync.
    ///
    /// `lastSync` is left alone: it marks the last full two-way pass, and a write-only run advancing it
    /// would misreport when NOOP last READ from Health.
    ///
    /// Shares the `syncing` flag with `sync()` on purpose: two write-backs must never interleave, because
    /// the vitals dedup deletes our prior samples for a key before saving the fresh batch. A call that
    /// arrives while another pass owns the bridge is coalesced into one final reconciliation rather than
    /// being dropped until the next app open.
    @discardableResult
    func writeBackAfterNewData() async -> Bool {
        // A backfill routinely completes in a process that was never foregrounded (a background offload,
        // or a BLE relaunch) - the case this exists for. `auth` is still `.unknown` there, because the
        // only resume runs on scenePhase == .active, so without this the guard below would silently drop
        // exactly the writes this is meant to deliver. Idempotent, and never prompts: it reads share
        // status, and its re-request for new types is foreground-gated.
        refreshAuthIfPreviouslyGranted()
        // No authorization is a successful no-op for a background task. The scheduler is cancelled by
        // its app-owned operation after observing this state, so it does not keep waking unnecessarily.
        guard auth == .authorized else { return true }
        guard !syncing else {
            writeBackPending = true
            return true
        }
        syncing = true
        defer { finishHealthPass() }
        guard let store = await repo.storeHandle() else { return false }
        do {
            try await writeBack(whoopStore: store)
            lastError = nil
            return true
        } catch {
            lastError = String(localized: "Apple Health sync failed: \(error.localizedDescription)")
            return false
        }
    }

    /// Release the single-flight gate and service one coalesced fresh-data signal. Scheduling a new task
    /// (rather than recursing in the defer) guarantees the current pass has fully returned first.
    private func finishHealthPass() {
        syncing = false
        guard writeBackPending else { return }
        writeBackPending = false
        Task { await writeBackAfterNewData() }
    }

    // MARK: - Write back (NOOP → Health)

    /// Write NOOP's strap-derived data into Apple Health: sleep sessions with full stage segments,
    /// the continuous 1-minute heart-rate stream, strap/manual workouts, and the nightly vitals
    /// (resting HR, HRV, SpO₂, respiratory rate) stamped at that day's wake time.
    ///
    /// Each feature saves independently and guards on ITS OWN type's share status, so one declined
    /// Health checkbox (or a save error) skips that feature without sinking the rest; the first error
    /// is rethrown at the end so `sync` still surfaces it in `lastError` without advancing `lastSync`.
    ///
    /// Dedup model (vitals): each emitted sample carries a deterministic `HKMetadataKeyExternalUUID`
    /// from `noopDeviceId + metric + day`. Before saving, we delete any of *our* prior samples that
    /// carry the same key (scoped to `HKSource.default()` so we never touch another app's data) and
    /// then save the fresh batch. HealthKit assigns a new UUID per save, so the previous strategy
    /// (no metadata, no delete) flooded Health with duplicates on every `sync()`.
    ///
    /// Throws on save failure so the caller can decide whether to advance `lastSync`.
    private func writeBack(whoopStore: WhoopStore, days: Int = 14) async throws {
        guard auth == .authorized else { return }
        let now = Date()
        guard let fromDate = Calendar.current.date(byAdding: .day, value: -days, to: now) else { return }
        let fromTs = Int(fromDate.timeIntervalSince1970)
        let nowTs = Int(now.timeIntervalSince1970)

        // Sleep sessions drive both the sleep write and the vitals' wake-time stamps: computed
        // sessions (deviceId + "-noop") first, imported rows override on startTs collision — the
        // same source precedence as the dailies union below and IntelligenceEngine's sleep reads.
        let computedSleeps = (try? await whoopStore.sleepSessions(deviceId: computedDeviceId, from: fromTs, to: nowTs, limit: 200)) ?? []
        let importedSleeps = (try? await whoopStore.sleepSessions(deviceId: noopDeviceId, from: fromTs, to: nowTs, limit: 200)) ?? []
        var sleepsByStart: [Int: CachedSleepSession] = [:]
        for s in computedSleeps { sleepsByStart[s.startTs] = s }
        for s in importedSleeps { sleepsByStart[s.startTs] = s }
        // A night the strap may still be recording is held back, with its day's vitals, until it closes
        // (`HealthWriteback.nightIsStillOpen`).
        // The strap's own heart rate, the same stream the HR write reads, so an Apple Watch still recording
        // cannot make a strap night that stopped at its sync frontier look finished.
        let newestHeartRateTs = (try? await whoopStore.hrFingerprint(deviceId: noopDeviceId, from: nowTs - 2 * 86_400,
                                                                     to: nowTs).maxTs) ?? 0
        let openStarts = Set(computedSleeps.filter {
            HealthWriteback.nightIsStillOpen(endTs: $0.endTs, newestHeartRateTs: newestHeartRateTs, now: nowTs)
        }.map(\.startTs))
        let sessions = sleepsByStart.keys.sorted().filter { !openStarts.contains($0) }.map { sleepsByStart[$0]! }
        let openDays = Set(computedSleeps.filter { openStarts.contains($0.startTs) }
            .map { HealthKitBridge.dayString(Date(timeIntervalSince1970: TimeInterval($0.endTs))) })

        var firstError: Error?
        func attempt(_ op: () async throws -> Void) async {
            do { try await op() } catch { if firstError == nil { firstError = error } }
        }
        // #1503: one-off sweep to clear records stranded under the OLD device-id-keyed scheme.
        // The old keys embedded the active strap id (`noop:<deviceId>:<kind>:<identity>`), which
        // became unreachable after a re-pair. The new keys drop the id segment, so the normal
        // delete-then-write can never find the old records. This sweep deletes ALL of our prior
        // records in the write-back window by `HKSource.default()` + date range (the same pattern
        // the HR path uses), then the normal writes re-add them under the new keys. Runs once,
        // gated by a UserDefaults flag, BEFORE the new-key writes so nothing is lost.
        await attempt { try await migrateStrandedHealthRecords(fromTs: fromTs, nowTs: nowTs) }
        await attempt { try await writeVitals(whoopStore: whoopStore, days: days, sessions: sessions, holdingDays: openDays) }
        await attempt { try await writeSleep(sessions: sessions) }
        await attempt { try await writeHeartRate(fromTs: fromTs, nowTs: nowTs) }
        await attempt { try await writeWorkouts(whoopStore: whoopStore, fromTs: fromTs, toTs: nowTs) }
        if let firstError { throw firstError }
    }

    /// UserDefaults key for the #1503 stranded-records sweep completion set. Stores the set of
    /// type ids whose sweep delete has SUCCEEDED, so a type that was unauthorized or whose delete
    /// failed is retried on a later write-back run rather than abandoned. Per-type (not a single
    /// boolean) because partial authorization is a supported state: a user who granted sleep but
    /// declined workouts must still get the stranded workouts swept once they later grant workouts,
    /// and a `deleteObjects` that threw must not read as "already done".
    private static let strandedRecordsSweptKey = "hkStrandedRecordsSweptTypes.v1"

    /// Stable type ids used in the per-type swept set. The quantity identifiers are the
    /// `HKQuantityTypeIdentifier` raw values; sleep and workout use fixed labels so the set is
    /// round-trippable through UserDefaults without depending on HealthKit type object identity.
    private static let sleepSweepTypeId = "sleepAnalysis"
    private static let workoutSweepTypeId = "workout"

    /// One-off migration (#1503): delete ALL of our prior Apple Health records in the write-back
    /// window that were written under the old device-id-keyed scheme. The old keys embedded the
    /// active strap id, which became unreachable after a re-pair; the new keys drop the id segment.
    /// This sweep uses `HKSource.default()` + date range (like the HR path) to reach records the
    /// new key-based delete predicate can never find. Runs BEFORE the new-key writes so the fresh
    /// batch re-adds everything under the stable keys.
    ///
    /// Completion is tracked PER-TYPE (not a single boolean): a type is marked swept only when its
    /// `deleteObjects` call returned a result (succeeded, even if it deleted zero records). A type
    /// that was unauthorized or whose delete threw is left un-swept, so a later authorization grant
    /// or a successful retry finishes the migration instead of abandoning the stranded records.
    /// The decision helpers live in `HealthWriteback` so they are unit-tested without HealthKit.
    private func migrateStrandedHealthRecords(fromTs: Int, nowTs: Int) async throws {
        let defaults = UserDefaults.standard
        let swept: Set<String> = Set(defaults.stringArray(forKey: Self.strandedRecordsSweptKey) ?? [])
        let bySource = HKQuery.predicateForObjects(from: HKSource.default())
        let byDate = HKQuery.predicateForSamples(
            withStart: Date(timeIntervalSince1970: TimeInterval(fromTs)),
            end: Date(timeIntervalSince1970: TimeInterval(nowTs) + 60),
            options: [])
        let pred = NSCompoundPredicate(andPredicateWithSubpredicates: [bySource, byDate])
        var succeededThisRun: Set<String> = []
        // Vitals: each quantity type that carried an id-keyed external UUID.
        for id in Self.quantityWriteIds {
            let typeId = id.rawValue
            guard !swept.contains(typeId),
                  let type = HKQuantityType.quantityType(forIdentifier: id),
                  store.authorizationStatus(for: type) == .sharingAuthorized else { continue }
            // `try?` returns nil on throw — a failure is NOT recorded as swept, so it retries next run.
            if (try? await store.deleteObjects(of: type, predicate: pred)) != nil {
                succeededThisRun.insert(typeId)
            }
        }
        // Sleep.
        if !swept.contains(Self.sleepSweepTypeId),
           let sleep = HKObjectType.categoryType(forIdentifier: .sleepAnalysis),
           store.authorizationStatus(for: sleep) == .sharingAuthorized {
            if (try? await store.deleteObjects(of: sleep, predicate: pred)) != nil {
                succeededThisRun.insert(Self.sleepSweepTypeId)
            }
        }
        // Workouts.
        if !swept.contains(Self.workoutSweepTypeId),
           store.authorizationStatus(for: .workoutType()) == .sharingAuthorized {
            if (try? await store.deleteObjects(of: .workoutType(), predicate: pred)) != nil {
                succeededThisRun.insert(Self.workoutSweepTypeId)
            }
        }
        // Persist only the types that actually succeeded this run; the rest stay pending.
        if !succeededThisRun.isEmpty {
            let updated = HealthWriteback.strandedSweepResult(swept: swept, succeededThisRun: succeededThisRun)
            defaults.set(Array(updated), forKey: Self.strandedRecordsSweptKey)
        }
    }

    /// The nightly vitals write (the original write-back), now stamped at the day's wake time when
    /// that day has a sleep session — a real timestamp inside the night the value describes, instead
    /// of a fabricated noon. Keys are unchanged, so re-stamped samples replace their noon ancestors.
    private func writeVitals(whoopStore: WhoopStore, days: Int, sessions: [CachedSleepSession],
                             holdingDays: Set<String> = []) async throws {
        let cal = Calendar.current
        let to = HealthKitBridge.dayString(Date())
        guard let fromDate = cal.date(byAdding: .day, value: -days, to: Date()) else { return }
        let from = HealthKitBridge.dayString(fromDate)

        // day (of wake) → wake instant. Ascending session order means the latest wake of a day wins,
        // matching collectSleep's end-date day attribution.
        var wakeByDay: [String: Date] = [:]
        for s in sessions where s.endTs > s.effectiveStartTs {
            let wake = Date(timeIntervalSince1970: TimeInterval(s.endTs))
            wakeByDay[HealthKitBridge.dayString(wake)] = wake
        }
        // Read NOOP's COMPUTED dailies (deviceId + "-noop"), which is the only place a strap-only
        // user's recovery/HRV/RHR/SpO₂/resp lives, then union with any imported `noopDeviceId` rows so
        // a user who ALSO imported a WHOOP export still gets the imported values. Imported overrides
        // computed per day, matching the dashboard's source precedence.
        let computed = (try? await whoopStore.dailyMetrics(deviceId: computedDeviceId, from: from, to: to)) ?? []
        let imported = (try? await whoopStore.dailyMetrics(deviceId: noopDeviceId, from: from, to: to)) ?? []
        var byDay: [String: DailyMetric] = [:]
        for r in computed { byDay[r.day] = r }   // computed first
        // Imported overrides, EXCEPT for a field the importer cannot populate. See HealthExportMerge: a
        // CSV carries no raw R-R, so an imported row never has `avgSdnn`, and replacing the row wholesale
        // threw away a computed SDNN that was already correct. The export then fell back to `avgHrv`
        // (RMSSD for a strap row) under the SDNN type, turning a right value into a wrong one on every day
        // an import happened to cover (#2264).
        for r in imported { byDay[r.day] = HealthExportMerge.merged(computed: byDay[r.day], imported: r) }
        let rows = byDay.keys.sorted().filter { !holdingDays.contains($0) }.map { byDay[$0]! }

        struct Candidate { let type: HKQuantityType; let key: String; let sample: HKQuantitySample }
        var candidates: [Candidate] = []
        func add(_ id: HKQuantityTypeIdentifier, _ unit: HKUnit, _ value: Double, _ day: String, _ at: Date) {
            guard let type = HKQuantityType.quantityType(forIdentifier: id),
                  store.authorizationStatus(for: type) == .sharingAuthorized else { return }
            // #1503: the key carries NO device-id segment. The previous scheme embedded the active
            // strap id, which is not durable — a re-pair changed it and stranded every prior record
            // in Apple Health as unreachable duplicates. The natural key (`noop:<metric>:<day>`)
            // matches the Android twin and is stable across strap lifecycle changes.
            let key = HealthWriteback.appleHealthVitalKey(metricId: id.rawValue, day: day)
            let sample = HKQuantitySample(
                type: type,
                quantity: .init(unit: unit, doubleValue: value),
                start: at, end: at,
                metadata: [HKMetadataKeyExternalUUID: key]
            )
            candidates.append(Candidate(type: type, key: key, sample: sample))
        }
        // Keys of OUR earlier samples to delete with no replacement: a value this build no longer writes
        // must not survive from a build that did.
        var retracted: [HKQuantityType: [String]] = [:]
        func retract(_ id: HKQuantityTypeIdentifier, _ day: String) {
            guard let type = HKQuantityType.quantityType(forIdentifier: id),
                  store.authorizationStatus(for: type) == .sharingAuthorized else { return }
            retracted[type, default: []].append(HealthWriteback.appleHealthVitalKey(metricId: id.rawValue, day: day))
        }

        for row in rows {
            guard let date = HealthKitBridge.date(from: row.day) else { continue }
            let noon = cal.date(bySettingHour: 12, minute: 0, second: 0, of: date) ?? date
            let at = wakeByDay[row.day] ?? noon
            if let rhr = row.restingHr {
                add(.restingHeartRate, HKUnit.count().unitDivided(by: .minute()), Double(rhr), row.day, at)
            }
            // Export only the GENUINE SDNN (v31). `avgSdnn` is the 5-min SDNN index, deliberately
            // window-matched to Apple's own short-window SDNN samples so the written values sit consistently
            // in the user's Health SDNN history (a whole-night SD would land 2-3× high).
            //
            // No `avgHrv` fallback (#2264). Every row here is a strap-computed or WHOOP-imported daily (rows
            // imported FROM Apple Health live under `appleDeviceId` and are never read back out), so `avgHrv` is always
            // RMSSD — a different magnitude that HealthKit has no type for. Writing it under
            // `.heartRateVariabilitySDNN` put a step into the series that no physiology produced, and a
            // Health reader that scores off SDNN took it at face value. A night without an SDNN (not yet
            // re-scored from raw R-R, or a summary-only source such as Oura) exports no HRV instead, and any
            // mislabelled sample an earlier build wrote for that day is retracted.
            if let sdnn = row.avgSdnn {
                add(.heartRateVariabilitySDNN, .secondUnit(with: .milli), sdnn, row.day, at)
            } else {
                retract(.heartRateVariabilitySDNN, row.day)
            }
            if let spo2 = row.spo2Pct {
                add(.oxygenSaturation, .percent(), spo2 / 100, row.day, at)
            }
            if let rr = row.respRateBpm {
                add(.respiratoryRate, HKUnit.count().unitDivided(by: .minute()), rr, row.day, at)
            }
        }
        guard !candidates.isEmpty || !retracted.isEmpty else { return }

        // Delete any of OUR prior samples that carry the same metadata keys, then write the fresh
        // batch. Scoped to HKSource.default() so we never touch a sample written by another app
        // that happens to use the same external UUID. Delete failures are non-fatal (e.g., nothing
        // to delete on first run) — only the save throws.
        let bySource = HKQuery.predicateForObjects(from: HKSource.default())
        var keysByType = Dictionary(grouping: candidates, by: { $0.type }).mapValues { $0.map { $0.key } }
        for (type, keys) in retracted { keysByType[type, default: []] += keys }
        for (type, allKeys) in keysByType {
            let keys = Array(Set(allKeys))
            let byKey = HKQuery.predicateForObjects(withMetadataKey: HKMetadataKeyExternalUUID,
                                                    allowedValues: keys)
            let pred = NSCompoundPredicate(andPredicateWithSubpredicates: [bySource, byKey])
            _ = try? await self.store.deleteObjects(of: type, predicate: pred)
        }
        guard !candidates.isEmpty else { return }
        try await self.store.save(candidates.map { $0.sample })
    }

    /// Write each BRIDGED NIGHT (#364) as one `.inBed` sample plus one category sample per stage
    /// segment (`deep → .asleepDeep`, `rem → .asleepREM`, `light → .asleepCore`, `wake → .awake`) —
    /// the same shape Oura and Apple Watch write, so Health renders the full hypnogram. A night the
    /// detector split on a brief mid-night wake exports as ONE entry whose gap is an explicit
    /// `.awake` segment (grouped by `SleepStageTotals.bridgedNightGroups`, the SAME bridge the daily
    /// totals score with, #561); naps never bridge and stay their own entries. Fragments whose
    /// `stagesJSON` carries no timing (the legacy aggregate-minutes shapes) get one honest
    /// `.asleepUnspecified` block instead of fabricated stage placement.
    ///
    /// Dedup: every sample of a night carries `HKMetadataKeyExternalUUID =
    /// noop:sleep:<startTs>` keyed by the group's EARLIEST fragment's immutable detected
    /// onset (a user edit moves the span, never the key). The delete predicate carries EVERY
    /// fragment's key, so a night previously written as two entries fully clears when it becomes
    /// one; delete-then-write scoped to our own `HKSource`, like the vitals. The key carries NO
    /// device-id segment (#1503): the active strap id is not durable, and embedding it stranded
    /// every prior record as unreachable duplicates after a re-pair.
    private func writeSleep(sessions: [CachedSleepSession]) async throws {
        guard let type = HKObjectType.categoryType(forIdentifier: .sleepAnalysis),
              store.authorizationStatus(for: type) == .sharingAuthorized else { return }
        let blocks = sessions.map { SleepStageTotals.NightBlock(start: $0.effectiveStartTs, end: $0.endTs) }
        let groups = SleepStageTotals.bridgedNightGroups(blocks, offsetSec: TimeZone.current.secondsFromGMT())
            .map { g in
                g.indices.map { i -> HealthWriteback.SleepFragment in
                    let s = sessions[i]
                    return .init(startTs: s.startTs, effectiveStartTs: s.effectiveStartTs,
                                 endTs: s.endTs, stagesJSON: s.stagesJSON)
                }
            }
        var samples: [HKCategorySample] = []
        var keys: [String] = []
        for entry in HealthWriteback.mergedSleepPlan(groups: groups) {
            let key = HealthWriteback.appleHealthSleepKey(startTs: entry.keyStartTs)
            let meta = [HKMetadataKeyExternalUUID: key]
            keys.append(contentsOf: entry.allKeyStartTs.map { HealthWriteback.appleHealthSleepKey(startTs: $0) })
            samples.append(HKCategorySample(type: type, value: HKCategoryValueSleepAnalysis.inBed.rawValue,
                                            start: Date(timeIntervalSince1970: TimeInterval(entry.spanStart)),
                                            end: Date(timeIntervalSince1970: TimeInterval(entry.spanEnd)),
                                            metadata: meta))
            for seg in entry.intervals {
                let value: HKCategoryValueSleepAnalysis
                switch seg.kind {
                case .awake:       value = .awake
                case .light:       value = .asleepCore
                case .deep:        value = .asleepDeep
                case .rem:         value = .asleepREM
                case .unspecified: value = .asleepUnspecified
                }
                samples.append(HKCategorySample(
                    type: type, value: value.rawValue,
                    start: Date(timeIntervalSince1970: TimeInterval(seg.start)),
                    end: Date(timeIntervalSince1970: TimeInterval(seg.end)),
                    metadata: meta))
            }
        }
        guard !samples.isEmpty else { return }
        let pred = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForObjects(from: HKSource.default()),
            HKQuery.predicateForObjects(withMetadataKey: HKMetadataKeyExternalUUID, allowedValues: keys),
        ])
        _ = try? await store.deleteObjects(of: type, predicate: pred)
        try await store.save(samples)
    }

    /// UserDefaults key for the HR write cursor (the newest bucket ts we've written). Per-strap so a
    /// device switch restarts the backfill for the new strap instead of resuming mid-stream.
    private var hrWriteCursorKey: String { "hkHRWriteCursor.v1.\(noopDeviceId)" }

    /// Write the strap's continuous heart rate as 1-minute mean samples — the same `hrBuckets` SQL
    /// the charts read (measured-first, PPG fallback), so Health sees exactly what NOOP plots. Raw
    /// ~1 Hz is deliberately downsampled: a fully-worn day is ~86k samples, which bloats the Health
    /// store; 1/min matches Apple Watch's background cadence.
    ///
    /// Dedup: forward-only cursor plus a 48 h rewrite window. Each run deletes OUR OWN prior HR
    /// samples in `[windowStart, now]` (source-scoped, date-range predicate — far cheaper than per-
    /// sample external-UUID keys at this volume) and rewrites the window, so a strap offload that
    /// backfills a recent night reconciles. Offloads older than 48 h behind the cursor are missed
    /// until the cursor is cleared — accepted trade-off for not re-walking 14 days every sync.
    private func writeHeartRate(fromTs: Int, nowTs: Int) async throws {
        guard let type = HKQuantityType.quantityType(forIdentifier: .heartRate),
              store.authorizationStatus(for: type) == .sharingAuthorized else { return }
        let cursor = UserDefaults.standard.integer(forKey: hrWriteCursorKey)
        let windowStart = cursor > 0 ? max(fromTs, cursor - 48 * 3600) : fromTs
        // Use the same active/registered/canonical union as the charts (#2644). Re-pairing
        // banks HR under a registry id, so reading only `noopDeviceId` silently misses it.
        let buckets = await repo.hrBuckets(from: windowStart, to: nowTs, bucketSeconds: 60)
        guard !buckets.isEmpty else { return }

        let pred = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForObjects(from: HKSource.default()),
            HKQuery.predicateForSamples(withStart: Date(timeIntervalSince1970: TimeInterval(windowStart)),
                                        end: Date(timeIntervalSince1970: TimeInterval(nowTs) + 60),
                                        options: []),
        ])
        _ = try? await store.deleteObjects(of: type, predicate: pred)

        let unit = HKUnit.count().unitDivided(by: .minute())
        var samples: [HKQuantitySample] = []
        samples.reserveCapacity(buckets.count)
        for b in buckets {
            let start = Date(timeIntervalSince1970: TimeInterval(b.ts))
            // Span the bucket, clamped so a bucket at the window edge can't end in the future
            // (HealthKit rejects future-dated samples).
            let end = Date(timeIntervalSince1970: TimeInterval(min(b.ts + 60, nowTs)))
            samples.append(HKQuantitySample(type: type,
                                            quantity: .init(unit: unit, doubleValue: b.bpm),
                                            start: start, end: max(start, end)))
        }
        // First run backfills ~20k samples (14 d × 1440/day); chunk the saves so no single HealthKit
        // transaction is oversized. Cursor only advances past what actually saved.
        var lastSaved = cursor
        var pending = samples[...]
        var pendingTs = buckets.map(\.ts)[...]
        while !pending.isEmpty {
            let chunk = Array(pending.prefix(5000))
            let chunkTs = Array(pendingTs.prefix(5000))
            pending = pending.dropFirst(chunk.count)
            pendingTs = pendingTs.dropFirst(chunk.count)
            try await store.save(chunk)
            lastSaved = max(lastSaved, chunkTs.last ?? lastSaved)
            UserDefaults.standard.set(lastSaved, forKey: hrWriteCursorKey)
        }
    }

    /// Write strap-detected and manual workouts into Health via `HKWorkoutBuilder`, with an
    /// `activeEnergyBurned` sample when the row has energy and a distance sample for distance
    /// sports. Workouts whose source is `apple-health` are EXCLUDED — those were imported FROM
    /// Health, and writing them back would duplicate the user's own Apple Watch/gym-app workouts.
    ///
    /// Dedup: `HKMetadataKeyExternalUUID = noop:workout:<startTs>` in the workout
    /// metadata; delete-then-write scoped to our own source, like sleep and the vitals. The key
    /// carries NO device-id segment (#1503): the active strap id is not durable, and embedding it
    /// stranded every prior workout as unreachable duplicates after a re-pair. Matches the Android
    /// twin's `noop-workout-<startTs>` `clientRecordId`.
    /// How many workout rows each write-back read asks the store for, per source.
    ///
    /// Named rather than inline because [deleteOrphanedWorkouts] has to compare against it: a read that
    /// comes back holding exactly this many rows may have been truncated, and a truncated read cannot be
    /// used to decide that a Health workout has no counterpart. (#2210)
    private static let workoutReadLimit = 500

    /// Delete the workouts we wrote into [fromTs, toTs] whose key is no longer among [keeping].
    ///
    /// Reads the window back from Health and deletes only objects that are ours by source AND carry a
    /// `noop:workout:` external UUID, so a workout written by another app, or by us under some future
    /// scheme, is never touched. Everything removed was observed first; nothing is deleted by range.
    ///
    /// A workout of ours with no external UUID at all is LEFT ALONE. It cannot be matched against the
    /// store, so deleting it would be guessing, and the #1503 sweep already exists for that class.
    ///
    /// ONE assumption this rests on, and it is newly load-bearing: that deleting an `HKWorkout` also
    /// removes the energy and distance samples `writeWorkouts` attached through its `HKWorkoutBuilder`.
    /// The key-based delete already assumed it, but harmlessly, because every delete there is followed
    /// immediately by a rewrite of the same key, so a surviving child is replaced rather than stranded.
    /// An orphan is deleted and NOT rewritten, so if the assumption is wrong its children are left in
    /// Health attributed to us with no workout above them, and nothing here will ever collect them.
    ///
    /// There is no fallback handle. `builder.addMetadata` puts the external UUID on the WORKOUT; the
    /// samples go through `builder.addSamples` carrying no metadata at all, so they cannot be found by
    /// key. Finding them by type and range instead would sweep `activeEnergyBurned` written by our own
    /// vitals path and by every other source, which is precisely the blind range delete this function
    /// exists to avoid. Verifying the assumption needs a device (#2210).
    ///
    /// Note also that this reads. `authorizationStatus` reports SHARE permission only, and HealthKit
    /// does not let an app ask whether it may read. With write granted and read withheld the query
    /// returns nothing rather than failing, so reconciliation quietly does nothing and the duplicates
    /// stay. That fails safe, but it fails silent.
    private func deleteOrphanedWorkouts(fromTs: Int, toTs: Int, keeping: Set<String>) async {
        let pred = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForObjects(from: HKSource.default()),
            // `.strictStartDate`, and it is load-bearing. A workout is an INTERVAL, and the default
            // options match anything overlapping the window, while the store read this is compared
            // against filters `startTs >= from AND startTs <= to`. Without strict matching, a workout
            // that began before `fromTs` and was still running at it is matched here, is absent from the
            // store read, and would therefore be deleted as an orphan. `fromTs` is a rolling 14-day
            // boundary recomputed on every write-back, so it lands mid-workout sooner or later.
            //
            // The heart-rate writer this reconciliation is modelled on uses the default options, and is
            // right to: its samples are instantaneous, so overlapping the window and starting inside it
            // are the same question. For an interval type they are not.
            HKQuery.predicateForSamples(withStart: Date(timeIntervalSince1970: TimeInterval(fromTs)),
                                        end: Date(timeIntervalSince1970: TimeInterval(toTs)),
                                        options: [.strictStartDate]),
        ])
        let orphans: [HKWorkout] = await withCheckedContinuation { (cont: CheckedContinuation<[HKWorkout], Never>) in
            let q = HKSampleQuery(sampleType: HKObjectType.workoutType(), predicate: pred,
                                  limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, samples, _ in
                var out: [HKWorkout] = []
                for case let workout as HKWorkout in samples ?? [] {
                    guard let uuid = workout.metadata?[HKMetadataKeyExternalUUID] as? String,
                          uuid.hasPrefix(HealthWriteback.appleHealthWorkoutKeyPrefix) else { continue }
                    if !keeping.contains(uuid) { out.append(workout) }
                }
                cont.resume(returning: out)
            }
            store.execute(q)
        }
        guard !orphans.isEmpty else { return }
        _ = try? await store.delete(orphans)
    }

    private func writeWorkouts(whoopStore: WhoopStore, fromTs: Int, toTs: Int) async throws {
        guard store.authorizationStatus(for: .workoutType()) == .sharingAuthorized else { return }
        // Read result kept OPTIONAL rather than collapsed with `?? []`, because the reconciliation below
        // has to tell "the store holds no workouts here" apart from "the read failed". Collapsed, a
        // transient read error would look like an empty window and delete every workout we had written
        // into it. (#2210)
        let mineRead = try? await whoopStore.workouts(deviceId: noopDeviceId, from: fromTs, to: toTs,
                                                      limit: Self.workoutReadLimit)
        let computedRead = try? await whoopStore.workouts(deviceId: computedDeviceId, from: fromTs, to: toTs,
                                                         limit: Self.workoutReadLimit)
        let mine = mineRead ?? []
        let computed = computedRead ?? []
        var byKey: [String: WorkoutRow] = [:]
        for w in computed + mine where w.source != HealthKitBridge.appleWorkoutSource {
            byKey["\(w.startTs):\(w.sport)"] = w
        }
        let rows = byKey.values.sorted { $0.startTs < $1.startTs }

        func key(_ row: WorkoutRow) -> String { HealthWriteback.appleHealthWorkoutKey(startTs: row.startTs) }

        // #2210: remove workouts we wrote that the store no longer holds. The delete below only ever
        // names the keys it is about to rewrite, so a row that LEFT the store keeps its Health copy for
        // good: a detected bout dropped for overlapping an Apple workout, a bout whose startTs drifted
        // and was rewritten under a new key, or a workout deleted, dismissed or merged in the app.
        //
        // Deliberately NOT a range delete. This reads the window back, keeps only what carries our own
        // key, and deletes the ones absent from `rows`, so nothing is removed that was not first
        // observed and identified as ours. A blind range delete would also have to trust that the store
        // read returned everything, and the two guards below are exactly the cases where it did not.
        //
        // Runs BEFORE the empty-rows return: a window whose last workout was deleted in the app is the
        // case where every Health copy is an orphan, and returning early would leave all of them.
        if mineRead != nil, computedRead != nil,
           mine.count < Self.workoutReadLimit, computed.count < Self.workoutReadLimit {
            await deleteOrphanedWorkouts(fromTs: fromTs, toTs: toTs, keeping: Set(rows.map(key)))
        }

        guard !rows.isEmpty else { return }
        let pred = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForObjects(from: HKSource.default()),
            HKQuery.predicateForObjects(withMetadataKey: HKMetadataKeyExternalUUID,
                                        allowedValues: rows.map(key)),
        ])
        _ = try? await store.deleteObjects(of: .workoutType(), predicate: pred)

        for row in rows {
            let start = Date(timeIntervalSince1970: TimeInterval(row.startTs))
            let end = Date(timeIntervalSince1970: TimeInterval(row.endTs))
            guard end > start else { continue }
            let config = HKWorkoutConfiguration()
            config.activityType = Self.activityType(forSport: row.sport)
            let builder = HKWorkoutBuilder(healthStore: store, configuration: config, device: .local())
            do {
                try await builder.beginCollection(at: start)
                try await builder.addMetadata([HKMetadataKeyExternalUUID: key(row)])
                var extras: [HKSample] = []
                if let kcal = row.energyKcal, kcal > 0,
                   let t = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned),
                   store.authorizationStatus(for: t) == .sharingAuthorized {
                    extras.append(HKQuantitySample(type: t, quantity: .init(unit: .kilocalorie(), doubleValue: kcal),
                                                   start: start, end: end))
                }
                if let meters = row.distanceM, meters > 0,
                   let id = Self.distanceTypeId(forSport: row.sport),
                   let t = HKQuantityType.quantityType(forIdentifier: id),
                   store.authorizationStatus(for: t) == .sharingAuthorized {
                    extras.append(HKQuantitySample(type: t, quantity: .init(unit: .meter(), doubleValue: meters),
                                                   start: start, end: end))
                }
                if !extras.isEmpty { try await builder.addSamples(extras) }
                try await builder.endCollection(at: end)
                let workout = try await builder.finishWorkout()

                // #2340: workout route write-back. Load the encoded polyline and its original point
                // measurements from the Apple-only side-store and attach them to the finished workout.
                // We only do this if the workout type supports a distance (GPS) route.
                if let workout,
                   Self.distanceTypeId(forSport: row.sport) != nil,
                   store.authorizationStatus(for: HKSeriesType.workoutRoute()) == .sharingAuthorized,
                   let route = RouteStore.loadWithPoints(startTs: row.startTs, sport: row.sport),
                   !route.polyline.isEmpty,
                   route.hasExportableMeasurements,
                   let points = route.points {
                    let routeBuilder = HKWorkoutRouteBuilder(healthStore: store, device: .local())
                    do {
                        let locs = points.map { point in
                            CLLocation(coordinate: CLLocationCoordinate2D(latitude: point.lat, longitude: point.lon),
                                       altitude: 0, horizontalAccuracy: point.accuracyM, verticalAccuracy: -1,
                                       timestamp: Date(timeIntervalSince1970: Double(point.tMs) / 1000))
                        }
                        try await routeBuilder.insertRouteData(locs)
                        try await routeBuilder.finishRoute(with: workout, metadata: nil)
                    } catch {
                        // Route is optional enrichment. Discard its uncommitted series and retain the workout.
                        routeBuilder.discard()
                        // HealthKit route attachment failures are intentionally silent: writeBack's
                        // lastError describes workout/sync failures, while this enrichment can safely be retried.
                    }
                }
            } catch {
                builder.discardWorkout()
                throw error
            }
        }
    }

    /// Reverse of `sportName`: NOOP's sport label → the `HKWorkoutActivityType` written to Health.
    /// Labels the forward map collapses (e.g. boxing/kickboxing → "Boxing") reverse to the first
    /// member; unknown labels fall back to `.other`, never dropped.
    private static func activityType(forSport sport: String) -> HKWorkoutActivityType {
        if sport == LiftingImporter.sport { return .traditionalStrengthTraining }
        switch sport.lowercased() {
        case "running":       return .running
        case "walking":       return .walking
        case "hiking":        return .hiking
        case "cycling":       return .cycling
        case "hiit":          return .highIntensityIntervalTraining
        case "core training": return .coreTraining
        case "yoga":          return .yoga
        case "pilates":       return .pilates
        case "rowing":        return .rowing
        case "elliptical":    return .elliptical
        case "stairs":        return .stairClimbing
        case "jump rope":     return .jumpRope
        case "boxing":        return .boxing
        case "basketball":    return .basketball
        case "soccer":        return .soccer
        case "football":      return .americanFootball
        case "baseball":      return .baseball
        case "badminton":     return .badminton
        case "tennis":        return .tennis
        case "table tennis":  return .tableTennis
        case "volleyball":    return .volleyball
        case "squash":        return .squash
        case "martial arts":  return .martialArts
        case "dancing":       return .dance
        case "golf":          return .golf
        case "climbing":      return .climbing
        case "skiing":        return .downhillSkiing
        case "snowboarding":  return .snowboarding
        case "swimming":      return .swimming
        case "surfing":       return .surfingSports
        case "paddling":      return .paddleSports
        default:              return .other
        }
    }

    /// Which distance quantity a sport's `distanceM` maps to; nil for sports whose Health distance
    /// type NOOP doesn't request share access for (e.g. swimming).
    private static func distanceTypeId(forSport sport: String) -> HKQuantityTypeIdentifier? {
        switch sport.lowercased() {
        case "running", "walking", "hiking": return .distanceWalkingRunning
        case "cycling":                      return .distanceCycling
        default:                             return nil
        }
    }

    private struct DayAgg {
        var restingHr: Double?; var avgHr: Double?; var maxHr: Double?; var hrv: Double?
        var spo2: Double?; var respRate: Double?; var steps: Double?
        var activeKcal: Double?; var basalKcal: Double?; var vo2max: Double?
        var weightKg: Double?; var bodyFatPct: Double?; var leanMassKg: Double?; var bmi: Double?
        var asleepMin: Double?; var deepMin: Double?; var remMin: Double?; var coreMin: Double?
        var waterMl: Double?
    }

    /// Excludes NOOP's own write-back samples from reads, so the two-way sync never reads its own
    /// output back in as "apple-health" data — which would make the strap and "Apple Health" plot the
    /// same line for a strap-only user, and bias the apple-health average for someone who also has a
    /// watch. `HKSource.default()` is this app's own source. (Reimplemented from @vulnix0x4's PR #375.)
    private static var notNoopAuthored: NSPredicate {
        NSCompoundPredicate(notPredicateWithSubpredicate: HKQuery.predicateForObjects(from: [HKSource.default()]))
    }

    /// Returns TRUE when the query completed, FALSE when HealthKit handed back an error.
    ///
    /// Every aggregate caller ignores this: a failed type simply contributes nothing to `DayAgg` and the
    /// affected fields stay nil, so no row is written for them. It matters only for a caller whose write
    /// REPLACES rather than adds (#949 imported water), where "read nothing" and "there is nothing" are
    /// the same empty result — and treating a failed query as an authoritative zero would wipe the
    /// stored figure for the whole window.
    @discardableResult
    /// Hourly cumulative step counts over `[start, end)`, mirroring `collect()`'s
    /// `HKStatisticsCollectionQuery` shape but bucketed by HOUR instead of day, so a backfill can show
    /// the shape of a day rather than one flattened total. `anchorDate` is local midnight — the same
    /// anchor `collect()` uses for its daily buckets — so hour buckets fall on local-clock hour
    /// boundaries, not UTC ones.
    ///
    /// WHAT A MISSING HOUR MEANS. Only hours with at least one step sample produce a row (HealthKit's
    /// `sumQuantity()` is nil for an empty bucket). So an absent hour means "no steps were recorded" —
    /// which covers a dead/left-behind phone AND an hour the wearer simply sat still. Step data carries
    /// no separate "was recording" signal, so a consumer must not label a gap as "phone off" on its own;
    /// it is evidence, not proof. Rows are never fabricated for empty hours.
    ///
    /// Throws on a HealthKit query error (distinguished from a genuinely-empty window, which returns
    /// zero rows) so a transient failure propagates to `sync()`'s existing `catch` instead of being
    /// mistaken for "no data".
    private func collectHourlySteps(start: Date, end: Date) async throws -> [(ts: Int, steps: Int)] {
        guard let type = HKQuantityType.quantityType(forIdentifier: .stepCount) else { return [] }
        let cal = Calendar.current
        let anchor = cal.startOfDay(for: start)
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate),
            Self.notNoopAuthored,
        ])
        return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<[(ts: Int, steps: Int)], Error>) in
            let q = HKStatisticsCollectionQuery(quantityType: type, quantitySamplePredicate: predicate,
                                                options: .cumulativeSum, anchorDate: anchor,
                                                intervalComponents: DateComponents(hour: 1))
            q.initialResultsHandler = { _, results, error in
                if let error {
                    cont.resume(throwing: error)
                    return
                }
                var rows: [(ts: Int, steps: Int)] = []
                results?.enumerateStatistics(from: start, to: end) { stats, _ in
                    if let sum = stats.sumQuantity() {
                        let steps = Int(sum.doubleValue(for: .count()).rounded())
                        rows.append((ts: Int(stats.startDate.timeIntervalSince1970), steps: steps))
                    }
                }
                cont.resume(returning: rows)
            }
            store.execute(q)
        }
    }

    /// What one HealthKit aggregate read is worth to a caller that will WRITE the result.
    ///
    /// `appleDaily`, `dailyMetric` and `metricSeries` all upsert with `column = excluded.column`, so a
    /// nil carried into a write REPLACES a stored value. A nil that came from a failed query therefore
    /// erases a good reading rather than recording an absence, which is #2561.
    ///
    /// `unavailable` is deliberately NOT a failure. A quantity type this device does not have will never
    /// have one, so absence IS the true answer and writing it is correct. Folding the two together would
    /// let one missing type abort every Health sync forever on that device.
    enum HealthRead {
        /// The query ran. Whatever it found, including nothing, is authoritative.
        case read
        /// The quantity type does not exist on this device. Nothing to read, now or later.
        case unavailable
        /// The query failed. The result says nothing about the metric and must not be written.
        case failed
    }

    private func collect(_ id: HKQuantityTypeIdentifier, unit: HKUnit, start: Date, end: Date,
                         op: HKStatisticsOptions, sink: @escaping (String, Double) -> Void) async -> HealthRead {
        guard let type = HKQuantityType.quantityType(forIdentifier: id) else { return .unavailable }
        let cal = Calendar.current
        let anchor = cal.startOfDay(for: start)
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate),
            Self.notNoopAuthored,
        ])
        return await withCheckedContinuation { (cont: CheckedContinuation<HealthRead, Never>) in
            let q = HKStatisticsCollectionQuery(quantityType: type, quantitySamplePredicate: predicate,
                                                options: op, anchorDate: anchor,
                                                intervalComponents: DateComponents(day: 1))
            q.initialResultsHandler = { _, results, error in
                // A nil `results` with an error is a FAILED read, not an empty one: it says nothing
                // about the metric, so a caller that writes must not write it. A query that RAN and
                // found nothing resumes `.read`, because absence is then a real answer.
                guard error == nil, let results else { cont.resume(returning: .failed); return }
                results.enumerateStatistics(from: start, to: end) { stats, _ in
                    let q: HKQuantity?
                    switch op {
                    case .cumulativeSum:     q = stats.sumQuantity()
                    case .discreteAverage:   q = stats.averageQuantity()
                    case .discreteMax:       q = stats.maximumQuantity()
                    case .discreteMostRecent: q = stats.mostRecentQuantity()
                    default:                 q = stats.averageQuantity()
                    }
                    if let q { sink(HealthKitBridge.dayString(stats.startDate), q.doubleValue(for: unit)) }
                }
                cont.resume(returning: .read)
            }
            store.execute(q)
        }
    }

    private func collectSleep(start: Date, end: Date,
                              sink: @escaping (String, Double?, Double?, Double?, Double?) -> Void) async {
        guard let type = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) else { return }
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForSamples(withStart: start, end: end, options: []),
            Self.notNoopAuthored,
        ])
        await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
            let q = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, samples, _ in
                var asleep: [String: Double] = [:], deep: [String: Double] = [:]
                var rem: [String: Double] = [:], core: [String: Double] = [:]
                for case let s as HKCategorySample in samples ?? [] {
                    let mins = s.endDate.timeIntervalSince(s.startDate) / 60
                    let day = HealthKitBridge.dayString(s.endDate)
                    switch s.value {
                    case HKCategoryValueSleepAnalysis.asleepDeep.rawValue:
                        deep[day, default: 0] += mins; asleep[day, default: 0] += mins
                    case HKCategoryValueSleepAnalysis.asleepREM.rawValue:
                        rem[day, default: 0] += mins; asleep[day, default: 0] += mins
                    case HKCategoryValueSleepAnalysis.asleepCore.rawValue, HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue:
                        core[day, default: 0] += mins; asleep[day, default: 0] += mins
                    default:
                        break
                    }
                }
                for day in Set(asleep.keys) {
                    sink(day, asleep[day], deep[day], rem[day], core[day])
                }
                cont.resume()
            }
            store.execute(q)
        }
    }

    // MARK: - Workouts (#835)

    /// Read the workouts the user logged in Apple Health over `[start, end)` and map each to a
    /// `WorkoutRow` under the apple-health source. ON-DEVICE ONLY: a straight HealthKit `HKWorkout` query,
    /// no cloud or third-party API. NOOP-authored workouts are excluded (the same `notNoopAuthored`
    /// predicate the metric reads use) so our own write-back never re-imports as "Apple Health". Mirrors
    /// the macOS export importer and the Android Health Connect importer, which already ingest workouts,
    /// closing the iOS gap. The upsert is idempotent on (deviceId, startTs), so re-running a sync window
    /// refreshes rather than duplicates.
    /// Individual caffeine samples in the window, newest first (#949).
    ///
    /// A SAMPLE query, not the day-bucketed `collect`: the caffeine card estimates what is still active
    /// from a half-life decay, so it needs each intake's own timestamp. A day total would collapse a 7am
    /// coffee and a 9pm one into a single number that answers no question the card asks.
    ///
    /// Each sample keeps its HealthKit UUID as `externalId` so a re-import can tell an intake it already
    /// has from a new one. `notNoopAuthored` keeps NOOP's own samples out — we do not write caffeine
    /// today, but the predicate costs nothing and closes the loop if that ever changes.
    ///
    /// Returns nil when the read FAILED, as distinct from an empty array meaning "no caffeine logged".
    /// The caller replaces the imported set wholesale, so collapsing those two cases would let a failed
    /// query silently delete every imported intake.
    private func collectCaffeine(start: Date, end: Date) async -> [CaffeineIntake]? {
        guard let type = HKQuantityType.quantityType(forIdentifier: .dietaryCaffeine) else { return nil }
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate),
            Self.notNoopAuthored,
        ])
        return await withCheckedContinuation { (cont: CheckedContinuation<[CaffeineIntake]?, Never>) in
            let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)
            let q = HKSampleQuery(sampleType: type, predicate: predicate,
                                  limit: HKObjectQueryNoLimit, sortDescriptors: [sort]) { _, samples, error in
                // The CAST is part of the failure test, not a fallback. `?? []` here would turn an
                // unexpected sample type into "no caffeine tonight", and the caller replaces the imported
                // set wholesale — so a cast that ever failed would silently delete every imported intake.
                // Same reasoning as the error check beside it.
                guard error == nil, let samples = samples as? [HKQuantitySample] else {
                    cont.resume(returning: nil); return
                }
                let out: [CaffeineIntake] = samples.compactMap { s in
                    let mg = s.quantity.doubleValue(for: .gramUnit(with: .milli))
                    // A zero or non-finite sample carries no dose worth showing; skip it rather than log
                    // a 0 mg intake, which would pad the "intakes still active" count with nothing.
                    guard mg.isFinite, mg > 0 else { return nil }
                    // The sample's OWN uuid as the intake id, not a fresh one. `CaffeineIntake` defaults
                    // `id` to `UUID()`, so minting one here would give the same coffee a different
                    // identity on every sync: `replaceImported`'s no-op guard would never match (a
                    // pointless JSON rewrite + republish each time), and `ForEach` would see the whole
                    // logged list as new rows and rebuild it. HealthKit sample uuids are stable.
                    return CaffeineIntake(id: s.uuid, at: s.startDate, mg: mg,
                                          externalId: s.uuid.uuidString)
                }
                cont.resume(returning: out)
            }
            store.execute(q)
        }
    }

    private func collectWorkouts(start: Date, end: Date) async -> [WorkoutRow] {
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate),
            Self.notNoopAuthored,
        ])
        // #1205: collect the HKWorkout objects alongside the rows so we can fetch their GPS routes
        // after the sample query completes. Routes are separate HKWorkoutRoute samples associated
        // with each workout; they cannot be read inside the sample query's completion handler
        // (HealthKit does not allow nested queries on the same store), so we hold the workouts and
        // fetch routes in a second pass below.
        let workoutsAndRows: [HKWorkout] = await withCheckedContinuation { (cont: CheckedContinuation<[HKWorkout], Never>) in
            let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)
            let q = HKSampleQuery(sampleType: HKObjectType.workoutType(), predicate: predicate,
                                  limit: HKObjectQueryNoLimit, sortDescriptors: [sort]) { _, samples, _ in
                cont.resume(returning: (samples ?? []).compactMap { $0 as? HKWorkout })
            }
            store.execute(q)
        }
        // #1205: fetch and store GPS routes for each workout. Best-effort — a route read failure
        // (permission not granted, no route data, HealthKit error) leaves the workout intact with
        // no map, which is exactly the pre-change behaviour. Stored via RouteStore under the same
        // (startTs, sport) key WorkoutDetailView loads from, so no UI change is needed.
        // Collected first and written ONCE. `RouteStore.store` rewrites the entire capped map on every
        // call, which is right for the recorder's single call at workout end but quadratic here: a
        // 500-workout first import would decode and re-encode a 400-entry map 500 times, on the order of
        // a gigabyte of JSON through UserDefaults. `storeAll` applies the same eviction, once.
        var importedRoutes: [(route: WorkoutRoute, startTs: Int, sport: String)] = []
        for workout in workoutsAndRows {
            if let route = await Self.fetchWorkoutRoute(for: workout, store: store),
               route.count >= 2 {
                let latLngs = route.map { RouteMath.LatLng($0.lat, $0.lon) }
                let polyline = RouteMath.encode(latLngs)
                let distanceM = RouteMath.totalMeters(latLngs)
                importedRoutes.append((WorkoutRoute(polyline: polyline, distanceM: distanceM, points: route),
                                       Int(workout.startDate.timeIntervalSince1970),
                                       Self.sportName(workout.workoutActivityType)))
            }
        }
        RouteStore.storeAll(importedRoutes)
        let profile = repo.strainProfile
        var rows: [WorkoutRow] = []
        rows.reserveCapacity(workoutsAndRows.count)
        for workout in workoutsAndRows {
            let startTs = Int(workout.startDate.timeIntervalSince1970)
            let endTs = max(Int(workout.endDate.timeIntervalSince1970), startTs)
            let appleSamples = await Self.fetchWorkoutHeartRate(for: workout, store: store)
            let steps = await Self.fetchWorkoutSteps(for: workout, store: store)
            // Prefer the HR stream HealthKit associates with this workout (for example, Apple Watch).
            // If that stream is absent or too sparse to score, fall back to the locally stored strap
            // trace for this exact workout window — the same trace that backs the detail chart.
            //
            // ONE stream answers the whole row. The streams are never merged, which would double-count
            // overlapping beats, and they are never split across fields either: a mean from the watch
            // beside an Effort integrated from the strap are two readings of one session that a wearer
            // cannot reconcile, and with no watch beats at all it would print an Effort with no heart
            // rate to account for it. So when the fallback is what scores the session, it reports that
            // session's mean and peak too.
            var samples = appleSamples
            var effort = profile.flatMap { Self.scoredEffort(appleSamples, profile: $0) }
            if effort == nil, let profile {
                let hrDeviceIds = Repository.workoutHrDeviceIds(
                    source: Self.appleWorkoutSource,
                    activeStrapId: repo.deviceId,
                    importedIds: repo.importedReadIds)
                let strapSamples = await repo.hrSamples(deviceIds: hrDeviceIds,
                                                        from: startTs, to: endTs,
                                                        limit: 20_000)
                if let strapEffort = Self.scoredEffort(strapSamples, profile: profile) {
                    effort = strapEffort
                    samples = strapSamples
                }
            }
            // Two gates, not one. A mean and a peak are readable from any beat the answering stream
            // carries, so they are reported whenever there are samples, which is what `WorkoutSource`
            // already does for a merged workout (`hrWeight > 0 ? … : nil`, no sample floor) rather than a
            // threshold invented here. EFFORT is the number that needs coverage: it integrates time in
            // zones, and a handful of beats over a few minutes would score a session never measured.
            //
            // Sharing one threshold meant a 15-sample, 8-minute workout with perfectly good heart rate
            // showed blank Avg and Max as well as blank Effort. It also meant a wearer with NO strain
            // profile got no heart rate at all from an import, because the old guard opened on
            // `guard let profile`: avg and max never needed one. Both still hold: when neither stream can
            // score an Effort, the watch's beats still answer the mean and peak.
            let heartRate: (avg: Int, peak: Int)? = {
                guard !samples.isEmpty else { return nil }
                let mean = Int((Double(samples.reduce(0) { $0 + $1.bpm }) / Double(samples.count)).rounded())
                return (mean, samples.map(\.bpm).max() ?? mean)
            }()
            rows.append(WorkoutRow(
                startTs: startTs, endTs: endTs,
                sport: Self.sportName(workout.workoutActivityType),
                source: HealthKitBridge.appleWorkoutSource,
                durationS: workout.duration > 0 ? workout.duration : Double(endTs - startTs),
                energyKcal: workout.totalEnergyBurned?.doubleValue(for: .kilocalorie()),
                avgHr: heartRate?.avg, maxHr: heartRate?.peak, strain: effort,
                distanceM: workout.totalDistance?.doubleValue(for: .meter()),
                zonesJSON: nil, notes: nil, steps: steps))
        }
        return rows
    }

    /// Beats an imported workout must carry before its EFFORT is scored.
    ///
    /// Effort integrates time in heart-rate zones, so it needs a session actually measured rather than a
    /// few beats sampled from one. Avg and Max deliberately do NOT sit behind this: they are honest at
    /// any sample count, and gating them here left workouts blank that HealthKit could answer.
    private static let effortMinimumSamples = 20

    /// Seconds an imported workout's beats must span before its EFFORT is scored. See
    /// [effortMinimumSamples]; twenty beats crowded into a minute is not ten minutes of measurement.
    private static let effortMinimumSpanSeconds = 600

    /// Score a workout only when its source stream has enough independent coverage to represent the
    /// session. Used first for HealthKit-associated HR and then for the WHOOP fallback; source samples
    /// are intentionally never combined.
    private static func scoredEffort(_ samples: [HRSample],
                                     profile: Repository.StrainProfile) -> Double? {
        guard let first = samples.first, let last = samples.last,
              samples.count >= effortMinimumSamples,
              last.ts - first.ts >= effortMinimumSpanSeconds else { return nil }
        return StrainScorer.strain(samples, maxHR: profile.hrMax,
                                   method: PuffinExperiment.effortMethod,
                                   sex: profile.sex)
    }

    /// HealthKit has no direct step-count property on HKWorkout; query step samples for its time window.
    /// Return nil on query failure or no usable samples, preserving "unknown" rather than reporting zero.
    nonisolated private static func fetchWorkoutSteps(for workout: HKWorkout,
                                                       store: HKHealthStore) async -> Int? {
        guard let type = HKQuantityType.quantityType(forIdentifier: .stepCount) else { return nil }
        let predicate = HKQuery.predicateForSamples(withStart: workout.startDate, end: workout.endDate,
                                                     options: .strictStartDate)
        return await withCheckedContinuation { (cont: CheckedContinuation<Int?, Never>) in
            let query = HKStatisticsQuery(quantityType: type, quantitySamplePredicate: predicate,
                                          options: .cumulativeSum) { _, statistics, error in
                guard error == nil,
                      let total = statistics?.sumQuantity()?.doubleValue(for: .count()),
                      total.isFinite, total >= 0 else {
                    cont.resume(returning: nil); return
                }
                cont.resume(returning: Int(total.rounded()))
            }
            store.execute(query)
        }
    }

    /// Read only HR samples associated with this HealthKit workout, excluding samples authored by NOOP.
    /// The workout association prevents same-window samples from unrelated sessions being counted.
    private static func fetchWorkoutHeartRate(for workout: HKWorkout,
                                               store: HKHealthStore) async -> [HRSample] {
        guard let type = HKQuantityType.quantityType(forIdentifier: .heartRate) else { return [] }
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            HKQuery.predicateForObjects(from: workout),
            Self.notNoopAuthored,
        ])
        return await withCheckedContinuation { (cont: CheckedContinuation<[HRSample], Never>) in
            let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)
            let query = HKSampleQuery(sampleType: type, predicate: predicate,
                                      limit: HKObjectQueryNoLimit, sortDescriptors: [sort]) { _, samples, error in
                guard error == nil, let samples = samples as? [HKQuantitySample] else {
                    cont.resume(returning: []); return
                }
                let unit = HKUnit.count().unitDivided(by: .minute())
                let result = samples.compactMap { sample -> HRSample? in
                    let bpm = sample.quantity.doubleValue(for: unit)
                    guard bpm.isFinite, bpm >= 25, bpm <= 240 else { return nil }
                    return HRSample(ts: Int(sample.startDate.timeIntervalSince1970), bpm: Int(bpm.rounded()))
                }
                cont.resume(returning: result)
            }
            store.execute(query)
        }
    }

    /// #1205: fetch the GPS route and its original timing/accuracy for a single `HKWorkout`.
    /// Queries `HKWorkoutRoute` samples overlapping the workout's time range, then collects all
    /// `CLLocation` waypoints from each route via `HKWorkoutRouteQuery`. Returns `nil` when there
    /// is no route, the user has not granted route read access, or HealthKit reports an error —
    /// all of which are graceful skips (the workout imports without a map, same as today).
    nonisolated static func fetchWorkoutRoute(for workout: HKWorkout, store: HKHealthStore) async -> [WorkoutRoutePoint]? {
        let routeType = HKSeriesType.workoutRoute()
        let predicate = HKQuery.predicateForSamples(withStart: workout.startDate, end: workout.endDate, options: .strictStartDate)
        // First: query for HKWorkoutRoute samples associated with this workout.
        let routes: [HKWorkoutRoute] = await withCheckedContinuation { (cont: CheckedContinuation<[HKWorkoutRoute], Never>) in
            let q = HKSampleQuery(sampleType: routeType, predicate: predicate,
                                  limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, samples, _ in
                let routeSamples = (samples as? [HKWorkoutRoute]) ?? []
                cont.resume(returning: routeSamples)
            }
            store.execute(q)
        }
        guard !routes.isEmpty else { return nil }
        // Second: collect CLLocation waypoints from each route. HKWorkoutRouteQuery calls its
        // handler repeatedly with batches of locations; `done: true` marks the end of one route.
        var points: [WorkoutRoutePoint] = []
        for route in routes {
            await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
                let query = HKWorkoutRouteQuery(route: route) { _, locations, done, _ in
                    for loc in locations ?? [] {
                        points.append(WorkoutRoutePoint(lat: loc.coordinate.latitude,
                                                        lon: loc.coordinate.longitude,
                                                        accuracyM: loc.horizontalAccuracy,
                                                        tMs: Int64(loc.timestamp.timeIntervalSince1970 * 1000)))
                    }
                    if done { cont.resume(returning: ()) }
                }
                store.execute(query)
            }
        }
        return points.isEmpty ? nil : points
    }

    /// Source tag stamped on workouts imported from Apple Health. Matches the macOS importer's
    /// `WorkoutSource.appleHealthSource` ("apple-health") and `appleDeviceId`, so the workout list and
    /// source filters treat an iOS-read workout exactly like a macOS-imported one.
    static let appleWorkoutSource = "apple-health"

    /// Map an `HKWorkoutActivityType` to NOOP's human sport label. Strength training routes to the
    /// shared lifting sport so a gym session lands in the Lifting lane; anything we don't name explicitly
    /// falls back to a generic "Workout" rather than an opaque numeric type.
    private static func sportName(_ type: HKWorkoutActivityType) -> String {
        switch type {
        case .running:                    return "Running"
        case .walking:                    return "Walking"
        case .hiking:                     return "Hiking"
        case .cycling:                    return "Cycling"
        case .traditionalStrengthTraining,
             .functionalStrengthTraining: return LiftingImporter.sport
        case .highIntensityIntervalTraining: return "HIIT"
        case .coreTraining:               return "Core training"
        case .yoga:                       return "Yoga"
        case .pilates:                    return "Pilates"
        case .rowing:                     return "Rowing"
        case .elliptical:                 return "Elliptical"
        case .stairClimbing, .stairs:     return "Stairs"
        case .jumpRope:                   return "Jump rope"
        case .boxing, .kickboxing:        return "Boxing"
        case .basketball:                 return "Basketball"
        case .soccer:                     return "Soccer"
        case .americanFootball:           return "Football"
        case .baseball:                   return "Baseball"
        case .badminton:                  return "Badminton"
        case .tennis:                     return "Tennis"
        case .tableTennis:                return "Table tennis"
        case .volleyball:                 return "Volleyball"
        case .squash, .racquetball:       return "Squash"
        case .martialArts, .taiChi:       return "Martial arts"
        case .dance, .cardioDance, .socialDance: return "Dancing"
        case .golf:                       return "Golf"
        case .climbing:                   return "Climbing"
        case .downhillSkiing, .crossCountrySkiing: return "Skiing"
        case .snowboarding:               return "Snowboarding"
        case .swimming:                   return "Swimming"
        case .surfingSports:              return "Surfing"
        case .paddleSports:               return "Paddling"
        default:                          return "Workout"
        }
    }

    // MARK: - Entitlement detection (#348)

    /// True when this running build actually carries the `com.apple.developer.healthkit` entitlement —
    /// i.e. it can genuinely reach Apple Health. False for a free-Apple-ID / AltStore / Sideloadly
    /// re-sign, which strips the HealthKit capability: the framework links and `isHealthDataAvailable()`
    /// is still true, but `requestAuthorization` is a dead-end and the app can never appear under
    /// Settings › Health › Data Access & Devices.
    ///
    /// Resolution order (most authoritative first), mirroring `IOSDiagnostics`'s profile parse:
    ///  1. If an `embedded.mobileprovision` is present (every dev / sideloaded / TestFlight build ships
    ///     one), slice the wrapped XML plist and look for `com.apple.developer.healthkit` in its
    ///     `Entitlements` dict. A free re-sign re-writes this profile WITHOUT that key. This is the
    ///     definitive signal and is unaffected by whether the user later granted/denied permission.
    ///  2. No embedded profile → an App Store install (App Store strips it). Those are properly signed
    ///     with whatever capabilities the app declares, so treat the entitlement as PRESENT. This is the
    ///     conservative default: it never down-routes a legitimately-signed build, so a user who simply
    ///     denied permission keeps the normal Settings guidance rather than the file-import reroute.
    ///
    /// Computed once and cached: the bundle's profile can't change within a process lifetime.
    static let hasHealthKitEntitlement: Bool = {
        guard let url = Bundle.main.url(forResource: "embedded", withExtension: "mobileprovision"),
              let data = try? Data(contentsOf: url) else {
            // No embedded profile = App Store build = properly signed. Assume present.
            return true
        }
        guard let xmlStart = data.range(of: Data("<?xml".utf8)),
              let xmlEnd = data.range(of: Data("</plist>".utf8)) else {
            // Profile present but unparseable — don't claim a missing entitlement off a parse failure;
            // assume present so we never wrongly down-route a real build.
            return true
        }
        let plistData = data.subdata(in: xmlStart.lowerBound..<xmlEnd.upperBound)
        guard let plist = try? PropertyListSerialization.propertyList(from: plistData, options: [], format: nil) as? [String: Any],
              let entitlements = plist["Entitlements"] as? [String: Any] else {
            return true
        }
        // The key is present (and truthy) on an entitled build; a free re-sign omits it entirely.
        return entitlements["com.apple.developer.healthkit"] != nil
    }()

    // MARK: - Date helpers

    // LOCAL civil day: the rest of the store keys days by the device-local civil day —
    // AppleHealthAggregator.localDay shifts each sample into its own offset, and
    // Repository.dayFormatter leaves timeZone at the default (local) zone. The
    // HKStatisticsCollectionQuery here already buckets in Calendar.current (anchor =
    // startOfDay, interval = 1 day), so labelling those local-midnight bucket starts with a
    // matching local formatter is strictly 1:1; using UTC instead mislabelled a full local day
    // under the previous UTC date for users east of UTC, so apple-health rows never merged with
    // the strap-computed/imported rows for the same civil day.
    // `nonisolated` so the HealthKit query completion handlers — which HealthKit invokes on a private
    // background queue (a nonisolated context) — can label day buckets without a main-actor-isolation
    // warning. They only read a thread-safe DateFormatter, so this is safe off the main actor.
    nonisolated private static let dayFormatter: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy-MM-dd"; f.timeZone = TimeZone.current; return f
    }()
    nonisolated private static func dayString(_ date: Date) -> String { dayFormatter.string(from: date) }
    nonisolated private static func date(from day: String) -> Date? { dayFormatter.date(from: day) }
}
#endif
