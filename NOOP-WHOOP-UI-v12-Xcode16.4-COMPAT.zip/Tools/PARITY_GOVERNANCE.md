# Parity governance

This directory contains the product-free foundation for tracking Swift/Kotlin
parity. It inventories declarations and constants, records the current accepted
debt, and prevents regeneration from accepting new debt silently.

## Local checks

Run the complete Python tool suite, then the two repository gates:

```sh
python3 -m unittest discover -s Tools -p 'test*.py'
python3 Tools/parity_ledger.py
python3 Tools/parity_ratchet.py --base origin/main --offline
```

The ledger must report no finding beyond the checked-in baseline. The ratchet
also rescans the working tree, so editing a baseline without matching current
sources fails closed. `--offline` skips only GitHub existence checks; it does
not relax syntax, schema, current-tree, or exact-base checks.

Scan errors are reported before baseline evaluation because unresolved or
malformed source evidence makes the inventory untrustworthy. In that case the
ledger ends with `Baseline not evaluated: N scan errors.`; fix the listed scan
errors before interpreting or refreshing baseline state.

For a reported debt decrease, the ledger resolves `--base` (default
`origin/main`) once to an immutable commit and proves the current identities are
a subset of that exact tree. A missing or shallow base fails closed.

The v3 twin map contains explicit source roots plus a count and SHA-256 for each
canonical semantic set. The full file/function/property/constant inventory is
derived deterministically from source; prose evidence and name-only suggestions
are not authority. A normal scan expands it and deep-checks every fingerprint.
The ratchet separately materializes and scans the exact base and current trees,
so regenerating both JSON files cannot hide a newly unpaired declaration. The ledger is
fail-closed when invoked; repository CI enforcement is intentionally deferred to the final
stack PR, alongside native execution and path-filtered ledger/ratchet invocation.

Function pairs exactly equal resolved attached source claims. File pairs derive
from those claims before constant resolution, so stale file metadata cannot
steer constant pairing. Swift selector labels disambiguate overloads. Stale,
overlapping, duplicate, or ambiguous attached-pair structure is a hard scan
error and cannot be accepted by the baseline. A claim originating in an
authority root may resolve to an exact declaration in the wider repository
reference scope; that external endpoint is hashed into the pair authority but
does not silently widen the unpaired-inventory roots.

The compact baseline stores exact-identity-set hashes grouped by rule and narrow
source scope. Every group has a review reason and provenance; no wildcard or
umbrella issue matches findings. Governance is intentionally asymmetric: new
or changed debt blocks, while a proven decrease is green with a concise warning.
No JSON regeneration or disposition cleanup is required merely to land an
improvement.

This PR is the governance foundation and executable demo. Its Python self-tests
run in a dedicated workflow when the governance implementation, authority,
tests, or workflow changes. Ordinary product-source and documentation changes
do not repeatedly self-test the scanner. The workflow does **not** invoke the
ledger or ratchet as a product-source gate yet. PR2 adds the portable case layer,
PR3 adds corpora and native runners, and PR4 wires product parity/differential
checks into required CI.
When PR4 wires this gate into CI, that invocation must omit
`--offline`. Every governed `issue` field must use the exact
`owner/repository#number` form. Online validation derives the API path from
that value and verifies both the repository and issue number; pull requests do
not satisfy an issue reference. A new experimental disposition additionally needs its
own fresh issue, a specific reason, and this marker in the issue body:

```text
parity-governance-identity-sha256: <the disposition's identity_sha256>
```

Issues cannot be reused across dispositions, and `bhelm/noop#17` is explicitly
forbidden as an umbrella.

## Updating the inventory

Initial creation is deliberately one-shot:

```sh
python3 Tools/parity_ledger.py --bootstrap-map --write-baseline
```

The two bootstrap flags are inseparable. Both snapshots are computed and
validated before either is published; a scan or publication failure leaves
both prior files byte-for-byte unchanged (or both absent on first creation).

Once authority exists, refresh derived snapshots only through the guarded flow:

```sh
python3 Tools/parity_ledger.py --refresh-derived --base origin/main
python3 Tools/parity_ledger.py
python3 Tools/parity_ratchet.py --base origin/main --offline
```

Generation computes state; it never approves it. Refresh writes candidates,
runs the identity-set ratchet against the exact base, and restores both snapshots
on failure. There is no accept/force switch, and the generator never creates or
edits `parity_dispositions.json`.
Deleting a paired duplicate is fail-closed derived-snapshot drift that requires
this guarded refresh flow by design.

If the scheduled `main` run finds that the exact base already contains stale
metadata, use the explicit repair variant:

```sh
python3 Tools/parity_ledger.py --refresh-derived --repair-stale-base --base origin/main
```

This is not a force switch and does not create a disposition. The ratchet
independently scans the exact base and the current tree, then permits the repair
only when semantic authority, finding identities, counters, and typed
dispositions are unchanged between them and both regenerated snapshots exactly
match that shared state. Any source debt introduced on the repair branch still
fails closed, as does a hand-edited or partial snapshot.

Repair therefore covers a base that is stale and OTHERWISE UNCHANGED. It cannot
cover a base whose stored authority no longer reproduces at all, which is what
merged product files leave behind: the governed state genuinely differs, so the
equality repair insists on can never hold. That case fails with

```
base authority cannot be reproduced with the current derivation; migration
required (see --migrate-authority)
```

and its remedy is the migration variant:

```sh
python3 Tools/parity_ledger.py --refresh-derived --migrate-authority --base origin/main
```

Migration re-bases the comparison onto a freshly derived base authority. It
waives exactly one thing, whether the base's STORED manifest can be reproduced,
and it is not a force switch either. New one-sided declarations are still
computed from the freshly derived base and current sets, so anything this branch
adds still needs its own issue-bound disposition and an undeclared one still
fails closed. A hand-edited current authority is refused outright.

Be clear-eyed about what a post-merge refresh does: it ADOPTS the one-sided
declarations already on `main` into the authority, because the ratchet governs
debt relative to the base and merged debt is the base. That is the intended
maintenance action, and it is also why the daily schedule matters. It finds the
drift within a day rather than letting it accumulate until a contributor
inherits it.

For a new one-sided declaration, choose explicitly:

The `add-unpaired-function` diagnostic defines "new" by absence of the
platform-qualified owner, name, and arity from the base declaration inventory,
not by a changed source line.

The ledger can report that diagnostic while its checked-in twin map still
describes the old source tree. Its pipe-separated finding identity is only a
source-drift diagnostic; it is **not** the platform-qualified, NUL-separated
authority identity accepted by `parity_dispositions.json`. Writing a disposition
does not make a scan against the old map pass. After choosing a remedy below,
run the guarded `--refresh-derived` flow above. That flow derives the current
authority, checks any new one-sided identity against the typed registry and
exact base, and restores both snapshots if the ratchet rejects the change.
Use the identity in the derived `unpaired_functions` set for a disposition,
including its platform prefix; do not copy the `add-unpaired-function|...`
diagnostic into the registry.

1. Implement and test its Swift/Kotlin twin (required for shared bug fixes and
   final shared features).
2. Manually add an `experimental` disposition with exact identity/platform,
   reason, fresh issue, and expiry date.
3. Manually add a durable `platform_specific` disposition with exact
   identity/platform and a concrete platform rationale.
4. For a Kotlin declaration whose Swift role twin lives in excluded `Strand/`,
   use `out_of_scope_twin` with an exact `twin_path` to that Swift file and a
   concrete rationale. This records the scope boundary; it does not prove that
   the implementations behave identically or create a governed pair.

These are the only disposition types. An inherited `platform_specific` entry
may be reclassified as `out_of_scope_twin` when the kind, identity, hash, and
platform stay identical and the Swift file exists under `Strand/`. Other edits
to inherited authority remain blocked. Dispositions cannot waive removal/retargeting of
an existing twin, a shared bug fix, or a final shared feature. The central typed
registry is manually reviewed; regeneration cannot populate it. A disposition
whose debt disappears emits a warning and may be removed later, but it never
authorizes reintroduction against the current merge base. Debt reductions pass
with a warning even when totals fall while another new identity remains
blocking.
Do not preserve stale findings or freeze commit hashes in tests; repository
consistency is proved by independent rescanning and canonical set hashes.

## Layer boundary

This foundation has no module runner, case corpus, coverage report, Gradle,
SwiftPM, governance-gate workflow invocation, or native-test dependency. The
path-filtered parity workflow only discovers the Python self-tests and protects
their count. Later layers can consume the inventory without making this scanner
depend on their orchestration.
